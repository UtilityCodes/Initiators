<?php
include '../../config.php';


// FOR CASH BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Cash
$queryCashIn = "SELECT SUM(payments.amount) AS total_cash_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'CASH' AND trans_type.name = 'Pay-In'";

$resultCashIn = $conn->query($queryCashIn);
$rowCashIn = $resultCashIn->fetch_assoc();
$totalCashIn = $rowCashIn['total_cash_in'];

// Fetch the total Pay-Out amount for Cash
$queryCashOut = "SELECT SUM(payments.amount) AS total_cash_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'CASH' AND trans_type.name = 'Pay-Out'";

$resultCashOut = $conn->query($queryCashOut);
$rowCashOut = $resultCashOut->fetch_assoc();
$totalCashOut = $rowCashOut['total_cash_out'];

// Calculate the Cash balance
$cashBalance = $totalCashIn - $totalCashOut;


// FOR BANK BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Bank
$queryBankIn = "SELECT SUM(payments.amount) AS total_bank_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'BANK' AND trans_type.name = 'Pay-In'";

$resultBankIn = $conn->query($queryBankIn);
$rowBankIn = $resultBankIn->fetch_assoc();
$totalBankIn = $rowBankIn['total_bank_in'];

// Fetch the total Pay-Out amount for Bank
$queryBankOut = "SELECT SUM(payments.amount) AS total_bank_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'BANK' AND trans_type.name = 'Pay-Out'";

$resultBankOut = $conn->query($queryBankOut);
$rowBankOut = $resultBankOut->fetch_assoc();
$totalBankOut = $rowBankOut['total_bank_out'];

// Calculate the Cash balance
$bankBalance = $totalBankIn - $totalBankOut;


// FOR MOBILE BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Mobile
$queryMobileIn = "SELECT SUM(payments.amount) AS total_mobile_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'MOBILE' AND trans_type.name = 'Pay-In'";

$resultMobileIn = $conn->query($queryMobileIn);
$rowMobileIn = $resultMobileIn->fetch_assoc();
$totalMobileIn = $rowMobileIn['total_mobile_in'];

// Fetch the total Pay-Out amount for Mobile
$queryMobileOut = "SELECT SUM(payments.amount) AS total_mobile_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'MOBILE' AND trans_type.name = 'Pay-Out'";

$resultMobileOut = $conn->query($queryMobileOut);
$rowMobileOut = $resultMobileOut->fetch_assoc();
$totalMobileOut = $rowMobileOut['total_mobile_out'];

// Calculate the Cash balance
$mobileBalance = $totalMobileIn - $totalMobileOut;

// **********
// Default date range: One week
$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');


// FOR REVENUE
// Fetch the total amount for Sale and Service_sale transactions within the date range
$queryRevenue = "SELECT SUM(payments.amount) AS total_revenue
                 FROM payments
                 JOIN transactions ON payments.trans_id = transactions.id
                 WHERE transactions.name IN ('Sale', 'Service_sale')
                 AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultRevenue = $conn->query($queryRevenue);
$rowRevenue = $resultRevenue->fetch_assoc();
$totalRevenue = $rowRevenue['total_revenue'];


// FOR SALES RETURN
// Fetch the total amount for Sale return transactions within the date range
$querySR = "SELECT SUM(payments.amount) AS total_sr
                 FROM payments
                 JOIN transactions ON payments.trans_id = transactions.id
                 WHERE transactions.name = 'Sale_return'
                 AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultSR = $conn->query($querySR);
$rowSR = $resultSR->fetch_assoc();
$totalSR = $rowSR['total_sr'];


// FOR TOTAL DEBIT
// Fetch the total amount for Purchase and Sale_return transactions from unique_activity table
$queryUniqueActivity = "SELECT SUM(actual_amount) AS total_debit_unique_activity
                       FROM unique_activity
                       JOIN transactions ON unique_activity.trans_id = transactions.id
                       WHERE transactions.name IN ('Purchase', 'Sale_return')
                       AND unique_activity.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";
                       

$resultUniqueActivity = $conn->query($queryUniqueActivity);
$rowUniqueActivity = $resultUniqueActivity->fetch_assoc();
$totalDebitUniqueActivity = $rowUniqueActivity['total_debit_unique_activity'];

// Fetch the total amount for Purchase and Sale_return transactions from payments table
$queryPayments = "SELECT SUM(payments.amount) AS total_debit_payments
                  FROM payments
                  JOIN transactions ON payments.trans_id = transactions.id
                  WHERE transactions.name IN ('Purchase', 'Sale_return')
                  AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultPayments = $conn->query($queryPayments);
$rowPayments = $resultPayments->fetch_assoc();
$totalDebitPayments = $rowPayments['total_debit_payments'];

// Calculate the Total Debit value
$totalDebit = $totalDebitUniqueActivity - $totalDebitPayments;


// FOR PURCHASES
// Fetch the total amount for Purchases transactions within the date range
$queryPurchases = "SELECT SUM(payments.amount) AS total_purchases
                 FROM payments
                 JOIN transactions ON payments.trans_id = transactions.id
                 WHERE transactions.name IN ('Purchases')
                 AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultPurchases = $conn->query($queryPurchases);
$rowPurchases = $resultPurchases->fetch_assoc();
$totalPurchases = $rowPurchases['total_purchases'];


// FOR PURCHASE RETURN
// Fetch the total amount for Purchase Return transactions within the date range
$queryPR = "SELECT SUM(payments.amount) AS total_pr
                 FROM payments
                 JOIN transactions ON payments.trans_id = transactions.id
                 WHERE transactions.name IN ('Purchase_return')
                 AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultPR = $conn->query($queryPR);
$rowPR = $resultPR->fetch_assoc();
$totalPR = $rowPR['total_pr'];


// FOR TOTAL CREDIT
// Fetch the total amount for Sale, Service Sale and Purchase_return transactions from unique_activity table
$queryUniqueActivity2 = "SELECT SUM(actual_amount) AS total_credit_unique_activity
                       FROM unique_activity
                       JOIN transactions ON unique_activity.trans_id = transactions.id
                       WHERE transactions.name IN ('Sale', 'Service_sale', 'Purchase_return')
                       AND unique_activity.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";
                       

$resultUniqueActivity2 = $conn->query($queryUniqueActivity2);
$rowUniqueActivity2 = $resultUniqueActivity2->fetch_assoc();
$totalCreditUniqueActivity = $rowUniqueActivity2['total_credit_unique_activity'];

// Fetch the total amount for Sale, Service Sale and Purchase_return transactions from payments table
$queryPayments2 = "SELECT SUM(payments.amount) AS total_credit_payments
                  FROM payments
                  JOIN transactions ON payments.trans_id = transactions.id
                  WHERE transactions.name IN ('Sale', 'Service_sale', 'Purchase_return')
                  AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

$resultPayments2 = $conn->query($queryPayments2);
$rowPayments2 = $resultPayments2->fetch_assoc();
$totalCreditPayments = $rowPayments2['total_credit_payments'];

// Calculate the Total Debit value
$totalCredit = $totalCreditUniqueActivity - $totalCreditPayments;



?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Dashboard For The Admin';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="dashbody">

            <!--Cash, Bank and Mobile-->
            <div class="dash-accounts">
                <div class="account-flex">

                    <!--The CASH CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Cash</span>
                                <div class="icon">
                                    <i class='bx bx-money' style="color: orange;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($cashBalance, 2); ?></figure>
                        </div>

                    </div>

                    <!--The BANK CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Bank</span>
                                <div class="icon">
                                    <i class='bx bxs-bank' style="color: lightgreen;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($bankBalance, 2); ?></figure>
                        </div>

                    </div>

                    <!--The MOBILE CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Mobile</span>
                                <div class="icon">
                                    <i class='bx bx-mobile' style="color: lightblue;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($mobileBalance, 2); ?></figure>
                        </div>

                    </div>

                </div>

            </div>

            <!-- Sales and Purchases Graphs-->
            <div class="graphs graphs-1">
                <div class="graph-flex">

                    <!--Sales Graph-->
                    <div class="canvas canvas-1">
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Sales</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date">
                                    </div>
                                    <div class="to-date">
                                        <input type="date">
                                    </div>
                                    <div class="date-filter-input">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="salesChart" class="line-bar-graphs"></canvas>
                        </div>

                    </div>
                    <!--Purchases Graphs-->
                    <div class="canvas canvas-2">

                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Purchases</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date">
                                    </div>
                                    <div class="to-date">
                                        <input type="date">
                                    </div>
                                    <div class="date-filter-input">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="purchaseChart" class="line-bar-graphs"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!--Revenue and purchases Cards-->
            <div class="cards cards-1">

                <div class="card-row-date-filter">
                    <div class="date-filter-card">
                        <div class="from-date">
                            <input type="date">
                        </div>
                        <div class="to-date">
                            <input type="date">
                        </div>
                        <div class="date-filter-input">
                            <button type="button">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-up">
                    <div class="card-row-flex">
                        <!--REVENUE CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Revenue</div>
                            <div class="row-card-figure"><?php echo number_format($totalRevenue, 2); ?></div>
                        </div>
                        <!--SALES RETURN CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Sales Return</div>
                            <div class="row-card-figure"><?php echo number_format($totalSR, 2); ?></div>
                        </div>
                        <!--TOTAL CREDIT-->
                        <div class="row-cards">
                            <div class="row-card-head">Total Debit</div>
                            <div class="row-card-figure"><?php echo number_format($totalDebit, 2); ?></div>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-down">
                    <div class="card-row-flex">
                        <!--PURCHASES CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Purchases</div>
                            <div class="row-card-figure"><?php echo number_format($totalPurchases, 2); ?></div>
                        </div>
                        <!--PURCHASE RETURN CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Purchase Return</div>
                            <div class="row-card-figure"><?php echo number_format($totalPR, 2); ?></div>
                        </div>
                        <!--TOTAL CREDIT-->
                        <div class="row-cards">
                            <div class="row-card-head">Total Credit</div>
                            <div class="row-card-figure"><?php echo number_format($totalCredit, 2); ?></div>
                        </div>
                    </div>
                </div>

            </div>

            <!--Payments and Expenses Graphs-->
            <div class="graphs graphs-2">
                <div class="graph-flex">

                    <!--PAYMENT GRAPH-->
                    <div class="canvas canvas-1">
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Payment</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date">
                                    </div>
                                    <div class="to-date">
                                        <input type="date">
                                    </div>
                                    <div class="date-filter-input">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="paymentsChart" class="line-bar-graphs"></canvas>
                        </div>

                    </div>
                    <!--EXPENSES GRAPH-->
                    <div class="canvas canvas-2">
                        
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Expenses</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date">
                                    </div>
                                    <div class="to-date">
                                        <input type="date">
                                    </div>
                                    <div class="date-filter-input">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="expensesChart" class="line-bar-graphs"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!--Payment Cards-->
            <div class="cards cards-2">

                <div class="card-row-date-filter">
                    <div class="date-filter-card">
                        <div class="from-date">
                            <input type="date">
                        </div>
                        <div class="to-date">
                            <input type="date">
                        </div>
                        <div class="date-filter-input">
                            <button type="button">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-up">
                    <div class="card-row-flex">
                        <!--PAYMENT-IN-->
                        <div class="row-cards">
                            <div class="row-card-head">Payment-In</div>
                            <div class="row-card-figure">5,500,000</div>
                        </div>
                        <!--PAYMENT-OUT-->
                        <div class="row-cards">
                            <div class="row-card-head">Payment-Out</div>
                            <div class="row-card-figure">1,278,000</div>
                        </div>
                        <!--CASH-IN-HAND-->
                        <div class="row-cards">
                            <div class="row-card-head">Cash-In-Hand</div>
                            <div class="row-card-figure">3,222,000</div>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-down">
                    <div class="card-row-flex">
                        <!--EXPENSES CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Expenses</div>
                            <div class="row-card-figure">750,000</div>
                        </div>
                        <!--DRAWINGS CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Drawings</div>
                            <div class="row-card-figure">1,350,000</div>
                        </div>
                        <!--TRANSFER CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Transfer</div>
                            <div class="row-card-figure">8</div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </section>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

    <script>
        document.addEventListener("DOMContentLoaded", function() {

        });
        // Dummy data
        const salesData = {
            labels: ["Jan", "Feb", "Mar", "Apr"],
            datasets: [{
                label: 'Total Sales',
                data: [50, 70, 45, 80],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };

        const purchaseData = {
            labels: ["Jan", "Feb", "Mar", "Apr"],
            datasets: [{
                label: 'Total Purchase',
                data: [30, 40, 35, 50],
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                fill: false
            }]
        };

        const paymentsData = {
            labels: ["Jan", "Feb", "Mar", "Apr"],
            datasets: [{
                label: 'Payment In',
                data: [20, 15, 25, 30],
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                fill: false
            },
            {
                label: 'Payment Out',
                data: [10, 8, 15, 20],
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                fill: false
            }]
        };


        const expensesData = {
            labels: ["Jan", "Feb", "Mar", "Apr"],
            datasets: [{
                label: 'Total Expenses',
                data: [40, 60, 50, 70],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };

        function createChart(chartId, chartData, chartType) {
            const ctx = document.getElementById(chartId).getContext('2d');
            new Chart(ctx, {
                type: chartType,
                data: chartData,
            });
        }

        createChart('salesChart', salesData, 'bar');
        createChart('purchaseChart', purchaseData, 'line');
        createChart('paymentsChart', paymentsData, 'line');
        createChart('expensesChart', expensesData, 'bar');
    </script>
    
    
    
    
    
    

</body>
</html>