<?php
// manager/purchases/view.php
include("../../config.php");

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session
?>
<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Purchase List';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <a href="add.php"><button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button></a>
                    

                </div>
                <div class="filter--btn" style="display:none;">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Code</th>
                        <th>Warehouse</th>
                        <th>Supplier</th>
                        <th>Status</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                    $sql =  "SELECT 
                                purchase.id as id,
                                purchase.code as code, 
                                purchase.dates as dates,
                                purchase.lpo_no as lpo,
                                purchase.proforma_no as proforma,
                                purchase.dn_no as dn,
                                supplier.name as sup,
                                warehouse.name as wh,
                                purchase.product_id as product_id,
                                purchase.price as price,
                                purchase.quantity as quantity,
                                unique_activity.actual_amount as actual_amount,
                                COALESCE(payments.amount_sum, 0) as total_amount,
                                CASE
                                    WHEN (unique_activity.actual_amount) = COALESCE(payments.amount_sum, 0) THEN 'Complete'
                                    WHEN (unique_activity.actual_amount) > COALESCE(payments.amount_sum, 0) THEN 'Incomplete'
                                    WHEN (unique_activity.actual_amount) < COALESCE(payments.amount_sum, 0) THEN 'Not Sure'
                                    WHEN COALESCE(payments.amount_sum, 0) = 0 THEN 'Not paid'
                                    ELSE ''
                                END AS status
                            FROM purchase
                            LEFT JOIN (
                                SELECT code, SUM(amount) as amount_sum
                                FROM payments
                                GROUP BY code
                            ) payments ON purchase.code = payments.code
                            INNER JOIN unique_activity ON purchase.code = unique_activity.code
                            INNER JOIN supplier ON purchase.supplier_id = supplier.id
                            INNER JOIN warehouse ON purchase.warehouse_id = warehouse.id
                            GROUP BY purchase.code
                            ORDER BY purchase.dates DESC, purchase.id DESC
";
       

                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['wh'];?></td>
                                <td class="td-action"><?php echo $row['sup'];?></td>
                                <td class="td-action"><?php echo $row['status'];?></td>
                                <!-- <td class="td-action">
                                     <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="edit-btn editBtn" data-id="">Edit</a>
                                            <a href="#" class="addPay">Add Payment</a>
                                            <a href="#" class="transDetails" data-id="">Purchase Details</a>
                                            <a href="#" class="productDetails">Product Details</a>
                                            <a href="#" class="payDetails">Payment Details</a>
                                            <a href="#" id="printReceipt">Print Receipt</a>
                                            <a href="#" id="quote">Quote</a>
                                            
                                        </span>
                                    </div>
                                </td>  -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>

            </table>
        </div>
    </section>


    <!--ACTION AREA-->

    <!--Add Payment-->
    <div class="view-popup">
        <div class="popup-container addPayContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Add Payment</h2>
                        </div>

                        <div class="cash-pay-inputs">
                            <div class="cash-payment">
                                <div class="cash-input">
                                    <label for="cashInput">Cash:</label>
                                    <input type="number" id="cashInput" name="cash-account">
                                </div>
                                <div class="change-input">
                                    <label for="change">Change:</label>
                                    <input type="number" name="change" id="change">
                                </div>
                            </div>
                            <div class="bank-note-mobile">
                                <div class="mobile-bank">
                                    <div class="bank-input">
                                        <label for="bank">Bank:</label>
                                        <input type="number" name="bank" id="bank">
                                    </div>
                                    <div class="mobile-input">
                                        <label for="mobile">Mobile:</label>
                                        <input type="number" name="mobile" id="mobile">
                                    </div>
                                </div>
                                <div class="note-input">
                                    <label for="note">Note:</label>
                                    <textarea name="note" id="note" cols="30" rows="10"></textarea>
                                </div>
                            </div>

                            <div class="other-pay">
                                <div class="other--input">
                                    <label for="">Other</label>
                                    <input type="number" name="account_id" id="accountId">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">
                        <div class="close-btn">
                            <button class="close-btn closeAddPay">CLOSE</button>
                        </div>
                        <div class="submit-btn">
                            <button class="submit-btn">ADD</button>
                        </div>
                    </div>

    
                </div>
            </div>
        </div>
    </div>

    <!--Transaction Details-->
    <?php
        include('purchase_details.php');
    ?>


    <!--Product Details-->
    <div class="view-popup">
        <div class="popup-container productDetailsContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Product Details</h2>
                        </div>

                        <div class="product-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Unit Price</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Washing Basin</td>
                                        <td>20,000</td>
                                        <td>3</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>


                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeProductDetails">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <!--Payment Details-->
    <div class="view-popup">
        <div class="popup-container payDetailsContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Payment Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Total Amount:</span>
                                <figure>300,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount Paid:</span>
                                <figure>120,000</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Type Of Transaction:</span>
                                <figure>Normal</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount Remaining:</span>
                                <figure>180,000</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">LPO NO:</span>
                                <figure>013</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">DN NO:</span>
                                <figure>017</figure>
                            </div>
                            <div class="div-3">
                                <span class="fixed-title">PROFORMA NO:</span>
                                <figure>210</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Total Discount:</span>
                                <figure>11,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closePayDetails">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


<!-- Edit details -->
<div class="popup-container editContainer">
    <div class="popup view-pop">
        <div class="popup-content">
            <form action="edit.php" method="post" class="sub-form horizontal-form">
                <div class="form-input form-heading">
                    <h2>Edit Purchase Details</h2>
                </div>

                <!-- Hidden input for purchase ID -->
                <input type="hidden" name="purchase_id" value="<?php echo $purchaseDetails['id']; ?>">

                <!-- Date input -->
                <div class="form-input text-input">
                    <label for="editDate">Date:</label><br>
                    <input type="date" name="editDate" id="editDate" >
                </div>

                <!-- Code input -->
                <div class="form-input text-input">
                    <label for="editCode">Code:</label><br>
                    <input type="text" name="editCode" id="editCode">
                </div>

                <!-- Supplier dropdown -->
                <div class="form-input text-input">
                    <label for="editSupplier">Supplier:</label><br>
                    <select id="editSupplier" name="editSupplier" required>
                        <option value="Supplier A"></option>
                    </select>
                </div>

                <!-- Warehouse dropdown -->
                <div class="form-input text-input">
                    <label for="editWarehouse">Warehouse:</label><br>
                    <select id="editWarehouse" name="editWarehouse" required>
                        <option value="WH-A">CX</option>  
                    </select>
                </div>

                <!-- Close and Update buttons -->
                <div class="form-btns">
                    <div class="close-btn">
                        <button class="close-btn closeEditBtn">CLOSE</button>
                    </div>
                    <div class="submit-btn">
                        <button type="submit" class="submit-btn">UPDATE</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>




    <!-- filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Cash Or Credit:</label><br>
                            <input list="cash-credit" class="datalist-input" id="cashCredit" name="cash_credit" autocomplete="off" required>

                            <datalist id="cash-credit">
                                <option value="Cash"></option>
                                <option value="Credit"></option>
                          
                            </datalist>
                        </div>


                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

    <script>
        $(document).ready(function () {
    function showPopup(popupClass) {
        $('.' + popupClass).fadeIn();
        $('.popup').addClass('active');
    }

    function hidePopup(popupClass) {
        $('.' + popupClass).fadeOut();
    }

    // Edit button
    $('.editBtn').on('click', function () {
        showPopup('editContainer');
    });

    $('.closeEditBtn').on('click', function () {
        hidePopup('editContainer');
    });

    // Filter button
    $('#pageFilterBtn').on('click', function () {
        showPopup('filterContainer');
    });

    $('#closeFilter').on('click', function () {
        hidePopup('filterContainer');
    });

    // Add Payment button
    $('.addPay').on('click', function () {
        showPopup('addPayContainer');
    });

    $('.closeAddPay').on('click', function () {
        hidePopup('addPayContainer');
    });

    // Transaction Details button
    $('.transDetails').on('click', function () {
        var purchaseId = $(this).data('id');

        $.ajax({
            url: 'get_purchase_details.php',
            method: 'GET',
            data: { purchaseId: purchaseId },
            success: function (data) {
                // Update the HTML with fetched details
                // $('.div-1 figure').text(data.date);
                // $('.div-2 figure').text(data.code);
                // $('.div-3 figure').text(data.supplierName);
                // $('.div-4 figure').text(data.supplierPhone);
                // $('.div-5 figure').text(data.supplierEmail);
                // $('.div-6 figure').text(data.warehouseName);
                // $('.div-7 figure').text(data.userName);
                // Add similar lines for other details
                // Update the HTML with fetched details
                updateDetail('.div-1 figure', data.purchase_date);
                updateDetail('.div-2 figure', data.purchase_code);
                updateDetail('.div-3 figure', data.supplier_name);
                updateDetail('.div-4 figure', data.supplier_phone);
                updateDetail('.div-5 figure', data.supplier_email);
                updateDetail('.div-6 figure', data.warehouse_name);
                updateDetail('.div-7 figure', data.user_name);


                // Show the popup
                $('.transDetailsContainer').fadeIn();
                $('.popup').addClass('active');
            },
            error: function () {
                console.log('Error fetching purchase details');
            }
        });
    });

    // Function to update detail in the HTML
    function updateDetail(selector, value) {
        $(selector).text(value);
    }

    $('.closeTransDetails').on('click', function () {
        hidePopup('transDetailsContainer');
    });

    // Product Details button
    $('.productDetails').on('click', function () {
        showPopup('productDetailsContainer');
    });

    $('.closeProductDetails').on('click', function () {
        hidePopup('productDetailsContainer');
    });

    // Payment Details button
    $('.payDetails').on('click', function () {
        showPopup('payDetailsContainer');
    });

    $('.closePayDetails').on('click', function () {
        hidePopup('payDetailsContainer');
    });
});

    </script>

    
</body>
</html>