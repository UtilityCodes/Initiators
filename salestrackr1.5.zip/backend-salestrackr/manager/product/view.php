<?php
// manager/product/view.php
// Include the database connection file
include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

function generateCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $code = 'prod-' . '-' . $timestamp;

    return $code;
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $brand_id = $_POST['brand_id'];
    $category_id = $_POST['category_id'];
    $unit_id = $_POST['unit_id'];
    $buying_price = $_POST['buying_price'];
    $selling_price = $_POST['selling_price'];
    $min_q = $_POST['min_q'];
    $note = $_POST['note'];

    if($code == null){
        $code = generateCode();      
    }
    if($note == null){
        $note = 'No Note';
    }

    // Insert data into the 'product' table
    $sql = "INSERT INTO product (code, name, brand_id, category_id, unit_id, buying_price, selling_price, min_q, note) VALUES ('$code', '$name', '$brand_id', '$category_id','$unit_id', '$buying_price','$selling_price', '$min_q', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Retrieve brand data for dropdown
$brand_query = "SELECT id, name FROM brand";
$brand_result = $conn->query($brand_query);
$brands = $brand_result->fetch_all(MYSQLI_ASSOC);

// Retrieve category data for dropdown
$category_query = "SELECT id, name FROM category";
$category_result = $conn->query($category_query);
$categories = $category_result->fetch_all(MYSQLI_ASSOC);

// Retrieve unit data for dropdown
$unit_query = "SELECT id, name FROM unit";
$unit_result = $conn->query($unit_query);
$units = $unit_result->fetch_all(MYSQLI_ASSOC);



// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Productia';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="productPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    <!--Add Brand Popup Form-->
                    <div class="popup-container" id="productFormContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Product Details</h2>
                                    </div>
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" required>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Category:</label><br>
                                            <input list="categoryNames" id="category" name="category_id" required>
                                            <datalist id="categoryNames">
                                                <?php
                                                    foreach ($categories as $category) {
                                                        echo "<option value='{$category['id']}'>{$category['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">Brand:</label><br>
                                            <input list="brandNames" id="brand" name="brand_id" required>
                                            <datalist id="brandNames">
                                                <?php
                                                    foreach ($brands as $brand) {
                                                        echo "<option value='{$brand['id']}'>{$brand['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>

                                    </div>

                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Buying Price:</label><br>
                                            <input type="number" name="buying_price" required>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Selling Price:</label><br>
                                            <input type="number" name="selling_price" required>
                                        </div>

                                    </div>
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Unit:</label><br>
                                            <input list="unitNames" id="unit" name="unit_id" required>
                                            <datalist id="unitNames">
                                                <?php
                                                    foreach ($units as $unit) {
                                                        echo "<option value='{$unit['id']}'>{$unit['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Alert Quantity:</label><br>
                                            <input type="number" name="min_q" value="10">
                                        </div>

                                    </div>
                                    <div class="input-row">
                                        
                                    <div class="form-input note-input">
                                        <label for="">Description:</label><br>
                                        <textarea name="note" id=""></textarea>
                                    </div>
                                    </div>

                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeProductForm" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="stock-btn" style="display:none">
                    <button type="button" id="productStockFilterPop" class="add-btn">STOCK</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Buying Price</th>
                        <th>Selling Price</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT id, code, name, buying_price as bp, selling_price as sp, note FROM product";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['bp']);?></td>
                                <td class="td-amount"><?php echo number_format($row['sp']);?></td>
                                <!-- <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn productViewPop">View</a>
                                            <a href="#" class="edit-btn productEditPop">Edit</a>
                                           
                                            <a href="#" class="filter-btn productTransFilterPop">Transactions</a>
                                            <a href="#">Print Barcode</a>
                                        </span>
                                    </div>
                                </td> -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for brand view-->
    <div class="edit-pop">
        <div class="popup-container productEditContainer" id="productEditContainer">
            <div class="popup view-pop">
                <div class="popup-content">
    
                    <form action="" class="sub-form horizontal-form">
                        <div class="form-input form-heading">
                            <h2>Add Product Details</h2>
                        </div>
                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="">Name:</label><br>
                                <input type="text" name="name" required>
                            </div>

                            <div class="form-input text-input">
                                <label for="">Code:</label><br>
                                <input type="text" name="code">
                            </div>

                        </div>

                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="">Category:</label><br>
                                <input list="categoryNames" id="category" name="category" required>
                                <datalist id="categoryNames">
                                    <option value="Category A"></option>
                                    <option value="Category B"></option>
                                    <option value="Category X"></option>
                                    <option value="Category Y"></option>
                                </datalist>
                            </div>
                            <div class="form-input text-input">
                                <label for="">Brand:</label><br>
                                <input list="brandNames" id="brand" name="brand" required>
                                <datalist id="brandNames">
                                    <option value="Brand A"></option>
                                    <option value="Brand B"></option>
                                    <option value="Brand X"></option>
                                    <option value="Brand Y"></option>
                                </datalist>
                            </div>

                        </div>

                        <div class="input-row">
                            
                            <div class="form-input text-input">
                                <label for="">Buying Price:</label><br>
                                <input type="number" name="buying_price" required>
                            </div>

                            <div class="form-input text-input">
                                <label for="">Selling Price:</label><br>
                                <input type="number" name="selling_price" required>
                            </div>

                        </div>
                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="">Unit:</label><br>
                                <input list="unitNames" id="unit" name="unit" required>
                                <datalist id="unitNames">
                                    <option value="Piece"></option>
                                    <option value="Kg"></option>
                                    <option value="Litre"></option>
                                    <option value="Boxes"></option>
                                </datalist>
                            </div>

                            <div class="form-input text-input">
                                <label for="">Alert Quantity:</label><br>
                                <input type="number" name="min_quantity" required>
                            </div>

                        </div>
                        <div class="input-row">
                            
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="" id="" cols="30" rows="3"></textarea>
                        </div>
                        </div>

                        <div class="form-btns">
                            <div class="close-btn">
                                <button id="closeProductEdit" class="close-btn closeProductEdit">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button class="submit-btn">ADD</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container productViewContainer" id="productViewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Product Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure>Paste-WD-300mg</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>578</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Brand:</span>
                                <figure>Whitedent</figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Category:</span>
                                <figure>Tooth-Paste</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Selling Price:</span>
                                <figure>1,200</figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Buying Price:</span>
                                <figure>950</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Unit:</span>
                                <figure>Piece</figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Alert Quantity:</span>
                                <figure>15</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Stock:</span>
                                <figure>23</figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button id="closeProductView" class="close-btn closeProductView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <!-- Stock filter popup-->
    <div class="view-popup">
        <div class="popup-container productStockFilterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Stock:</h2>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A">
                                <option value="Warehouse X">
                                <option value="Warehouse i">
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeProductFilter" class="close-btn closeProductFilter">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container productTransFilterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Transactions:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Transactions:</label><br>
                            <input list="transactions" class="datalist-input" id="trans-actions" name="trans-actions" autocomplete="off" required>

                            <datalist id="transactions">
                                <option value="Purchase"></option>
                                <option value="Sale"></option>
                                <option value="Service Sale"></option>
                                <option value="Purchase Return"></option>
                                <option value="Sale Return"></option>
                                <option value="Transfer"></option>
                                
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeProductFilter" class="close-btn closeProductFilter">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

            // FOR ADD-Product BUTTON ****
            $('#productPopBtn').on('click', function () {
                $('#productFormContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeProductForm').on('click', function () {
                $('#productFormContainer').fadeOut();
            });

            $('#productPopBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR EDIT-Product BUTTON ****
            $('.productEditPop').on('click', function () {
                $('#productEditContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeProductEdit').on('click', function () {
                $('#productEditContainer').fadeOut();
            });

            $('.productEditPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW-Product BUTTON ****
            $('.productViewPop').on('click', function () {
                $('#productViewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeProductView').on('click', function () {
                $('#productViewContainer').fadeOut();
            });

            $('.productViewPop').on('click', function () {
                $('.popup').addClass('active');
            });


            
            // FOR STOCK FILTER BUTTON *****
            $('#productStockFilterPop').on('click', function () {
                $('.productStockFilterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeProductFilter').on('click', function () {
                $('.productStockFilterContainer').fadeOut();
            });

            $('#productStockFilterPop').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR TRANSACTION FILTER-Product BUTTON ****
            $('.productTransFilterPop').on('click', function () {
                $('.productTransFilterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeProductFilter').on('click', function () {
                $('.productTransFilterContainer').fadeOut();
            });

            $('.productTransFilterPop').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>  
    
    

</body>
</html>