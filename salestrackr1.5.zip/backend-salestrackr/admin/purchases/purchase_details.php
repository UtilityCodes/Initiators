<div class="view-popup">
        <div class="popup-container transDetailsContainer">
            <div class="popup view-pop">

            <div class="popup-content">
                    
                    <?php
                    include("../../config.php");
    // purchase_details.php
    
    
    // Assume $purchaseId is the variable holding the purchase ID
    $purchaseId = isset($_GET['purchaseId']) ? $_GET['purchaseId'] : null;
    
    // Fetch the purchase details from the database
    if ($purchaseId) {
        $purchaseDetailsSql = "SELECT 
                purchase.dates AS purchase_date,
                purchase.code AS purchase_code,
                supplier.name AS supplier_name,
                supplier.phone AS supplier_phone,
                supplier.email AS supplier_email,
                warehouse.name AS warehouse_name,
                user.name AS user_name
            FROM purchase
            LEFT JOIN supplier ON purchase.supplier_id = supplier.id
            LEFT JOIN warehouse ON purchase.warehouse_id = warehouse.id
            LEFT JOIN user ON purchase.user_id = user.id
            WHERE purchase.id = $purchaseId";
    
        $purchaseDetailsResult = $conn->query($purchaseDetailsSql);
    
        if ($purchaseDetailsResult->num_rows > 0) {
            $purchaseDetails = $purchaseDetailsResult->fetch_assoc();
    ?>
            <div class="view-section">
                <div class="view-heading">
                    <h2>Purchase Details</h2>
                </div>
                <div class="view-div">
                    <div class="div-1">
                        <span class="fixed-title">Date Of Purchase:</span>
                        <figure><?php echo $purchaseDetails['purchase_date']; ?></figure>
                    </div>
                    <div class="div-2">
                        <span class="fixed-title">Code:</span>
                        <figure><?php echo $purchaseDetails['purchase_code']; ?></figure>
                    </div>
                </div>
                <div class="view-div">
                    <div class="div-1">
                        <span class="fixed-title">Supplier:</span>
                        <figure><?php echo $purchaseDetails['supplier_name']; ?></figure>
                    </div>
                    <div class="div-2">
                        <span class="fixed-title">Contacts:</span>
                        <figure>
                            <p><?php echo $purchaseDetails['supplier_phone']; ?></p>
                            <p><?php echo $purchaseDetails['supplier_email']; ?></p>
                        </figure>
                    </div>
                </div>
                <div class="view-div">
                    <div class="div-1">
                        <span class="fixed-title">Warehouse:</span>
                        <figure><?php echo $purchaseDetails['warehouse_name']; ?></figure>
                    </div>
                    <div class="div-2">
                        <span class="fixed-title">User:</span>
                        <figure><?php echo $purchaseDetails['user_name']; ?></figure>
                    </div>
                </div>
            </div>
    <?php
        }
    }
    ?>
    
                        <div class="form-btns">
    
                            <div></div>
                            
                            <div class="close-btn">
                                <button class="close-btn closeTransDetails">CLOSE</button>
                            </div>
    
                        </div>
        
                    </div>


            </div>
        </div>
    </div>
