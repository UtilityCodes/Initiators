<?php
include('../../config.php');

if (isset($_GET['purchaseId'])) {
    $purchaseId = $_GET['purchaseId'];

    // Query to fetch purchase details
    $sql = "SELECT purchase.dates AS date, purchase.code, supplier.name AS supplierName, supplier.phone, supplier.email, warehouse.name AS warehouseName, user.name AS userName
            FROM purchase
            JOIN supplier ON purchase.supplier_id = supplier.id
            JOIN warehouse ON purchase.warehouse_id = warehouse.id
            JOIN user ON purchase.user_id = user.id
            WHERE purchase.id = $purchaseId";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo json_encode(['error' => 'Purchase details not found']);
    }
} else {
    echo json_encode(['error' => 'Invalid request']);
}

