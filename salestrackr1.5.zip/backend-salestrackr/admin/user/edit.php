<?php
// admin/user/edit.php
// Include database connection
include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

// Check if user ID is provided
if(isset($_GET['id'])) {
    // Retrieve user ID from query parameters
    $userId = $_GET['id'];

    // Retrieve user details from the database
    $sql = "SELECT * FROM user WHERE id = $userId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch user details
        $user = $result->fetch_assoc();
    } else {
        // User not found, handle error
        echo "User not found";
        exit();
    }
} else {
    // No user ID provided, handle error
    echo "No user ID provided";
    exit();
}

// Check if form is submitted for updating user details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
    // Retrieve user ID from hidden input field
    $userId = $_POST["user_id"];
    
    // Retrieve form data
    $name = $_POST["name"];
    $code = $_POST["code"];
    $passcode = $_POST["passcode"];
    $role_id = $_POST["role_id"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $warehouse_id = $_POST["warehouse_id"];
    $note = $_POST["note"];

    // Prepare and execute SQL update statement
    $stmt = $conn->prepare("UPDATE user SET name=?, code=?, passcode=?, role_id=?, phone=?, email=?, warehouse_id=?, note=? WHERE id=?");
    $stmt->bind_param("sssisissi", $name, $code, $passcode, $role_id, $phone, $email, $warehouse_id, $note, $userId);

    if ($stmt->execute()) {
        // Redirect to view page or show success message
        header("Location: view.php"); // Replace 'view.php' with your actual view page
        exit();
    } else {
        // Handle update error
        echo "Error updating user: " . $conn->error;
    }


}





// Retrieve role data for dropdown
$role_query = "SELECT id, name FROM role";
$role_result = $conn->query($role_query);
$roles = $role_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);




// Close statement and connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Users';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--edit details-->
                    <div class="popup-container" id="addContainer" style="display:block">
                        <div class="popup view-pop" style="display:block">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Edit User Details</h2>
                                    </div>
                                    <div class="input-row">

                                        <!-- Include a hidden input field for user ID -->
                                        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" id="name" name="name" value="<?php echo $user['name']; ?>" required><br>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" id="code" name="code" value="<?php echo $user['code']; ?>" required><br>
                                        </div>
            
                                    </div>

                                    
                                    <div class="input-row">

                                        
                                        <div class="form-input text-input">
                                            <label for="">Password:</label><br>
                                            <input type="text" id="passcode" name="passcode" value="<?php echo $user['passcode']; ?>" required><br>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Role:</label><br>
                                            <select id="role_id" name="role_id" required>
                                                <?php foreach ($roles as $role): ?>
                                                    <option value="<?php echo $role['id']; ?>" <?php if ($role['id'] == $user['role_id']) echo 'selected'; ?>><?php echo $role['name']; ?></option>
                                                <?php endforeach; ?>
                                            </select><br>
                                        </div>


                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="text" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required><br>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required><br>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <select id="warehouse_id" name="warehouse_id" required>
                                                <?php foreach ($warehouses as $warehouse): ?>
                                                    <option value="<?php echo $warehouse['id']; ?>" <?php if ($warehouse['id'] == $user['warehouse_id']) echo 'selected'; ?>><?php echo $warehouse['name']; ?></option>
                                                <?php endforeach; ?>
                                            </select><br>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea id="note" name="note"><?php echo $user['note']; ?></textarea><br>
                                        </div>

                                        
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <a href="view.php">
                                                <button id="closeBtn" class="close-btn">CLOSE</button>
                                            </a>
                                            
                                        </div>
                                        <div class="submit-btn">
                                            <button name="update" class="submit-btn">UPDATE</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

    </section>


    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>
    

</body>
</html>