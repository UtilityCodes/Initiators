<?php
// Include the database connection file
include('../../config.php');

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $product_id = $_POST['product_id'];
    $original_price = $_POST['original_price'];
    $percent_discount = $_POST['percent_discount'];
    $new_price = $_POST['new_price'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $note = $_POST['note'];

    // Insert data into the 'product' table
    $sql = "INSERT INTO on_sale (code, product_id, original_price, percent_discount, new_price, from_date, to_date, note) VALUES ('$code','$product_id', '$original_price', '$percent_discount', '$new_price', '$from_date', '$to_date', '$note',)";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


// Retrieve account data for dropdown
$product_query = "SELECT id, name, selling_price FROM product";
$product_result = $conn->query($product_query);
$products = $product_result->fetch_all(MYSQLI_ASSOC);


// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>On-SALE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="shortcut icon" href="../../assets/images/st-logo.jpg" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <style>

       

    </style>
</head>
<body>
    
        
    <nav id="sidebar">
        <header class="left-header">
            <div class="nav-header">
                <img src="../../assets/images/st-logo.jpg" alt="">
                <span>SalesTrackr</span>
                <div class="close"><i class="fa fa-times"></i></div>
            </div>
        </header>
        
        <ul class="side-list">
            <li><a href="#"><i class="fa fa-th"></i>Dashboard</a></li>
            <li><a href="" class="main-menu"><i class="fa fa-pencil-square-o"></i>Register</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-copyright"></i>Brand</a></li>
                    <li><a href="#"><i class="fa fa-sitemap"></i>Category</a></li>
                    <li><a href="#"><i class="fa fa-television"></i>Product</a></li>
                    <li><a href="#"><i class="fa fa-motorcycle"></i>Service</a></li>
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-credit-card"></i>Purchases</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-plus"></i>Add Purchases</a></li>
                    <li><a href="#"><i class="fa fa-list-ol"></i>Purchase List</a></li>
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-shopping-cart"></i>Sales</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-plus"></i>Add Sales</a></li>
                    <li><a href="#"><i class="fa fa-list-ol"></i>Sale List</a></li>
                    <li><a href="#"><i class="fa fa-plus"></i>Add Service Sale</a></li>
                    <li><a href="#"><i class="fa fa-list-ol"></i>Service Sale List</a></li>
                    <li><a href="#"><i class="fa fa-list-ol"></i>Coupon</a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-quote-right"></i>Quotation</a></li>
            <li><a href="#"><i class="fa fa-rocket"></i>On Sale</a></li>
            <li><a href="" class="main-menu"><i class="fa fa-undo"></i>Transactions</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-forward"></i>Payments</a></li>
                    <li><a href="#"><i class="fa fa-backward"></i>Drawings</a></li>
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-undo"></i>Returns</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-plus"></i>Add P Returns</a></li>
                    <li><a href="#"><i class="fa fa-forward"></i>Purchase Returns</a></li>
                    <li><a href="#"><i class="fa fa-plus"></i>Add S Returns</a></li>
                    <li><a href="#"><i class="fa fa-backward"></i>Sale Returns</a></li>
                </ul>
            </li>
           
            <li><a href="" class="main-menu"><i class="fa fa-exchange"></i>Transfer</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-plus"></i>Add Transfer</a></li>
                    <li><a href="#"><i class="fa fa-list-ol"></i>Transfer List</a></li>
                    
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-users"></i>People</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-user"></i>Customer</a></li>
                    <li><a href="#"><i class="fa fa-user-o"></i>Supplier</a></li>
                    <li><a href="#"><i class="fa fa-user-circle-o"></i>User</a></li>
                </ul>
            </li>
            
            <li><a href="" class="main-menu"><i class="fa fa-money"></i>Expenses</a>
                <ul class="sub-menu">
                    <li><a href="#"><i class="fa fa-plus"></i>Type</a></li>
                    <li><a href="#"><i class="fa fa-money"></i>Expenses</a></li>
                    
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-building"></i>Warehouses</a></li>
        </ul>           
    </nav>
            
        
   
    <section class="content">
        <header class="header-mp">
            <div class="header-flex">
                <div class="burger left" id="burger-icon"><i class="fa fa-bars"></i></div>
                <div class="middle">
                    <!-- <div class="timestamp">Tuesday, February 6, 2024 at 4:24:00 PM</div> -->
                    <div class="profile">
                        <span class="user">Karina Ushao<i class="fa fa-chevron-down"></i></span>
                        <div class="user-dropdown">
                            <a href="">Log-out</a>
                        </div>
                    </div>
                </div>
                <div class="right">
                    <span class="notify">
                        <a href="">
                            <i class="fa fa-bell"></i>
                            <div class="digit">1</div>
                        </a>
                    </span>
                    <span class="pos-btn"><button>POS</button></span>
                    
                </div>
            </div>
            
        </header>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>Add On-Sale Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Product:</label><br>
                                            <input list="products" id="productId" name="product_id" required>
                                            <datalist id="warehouses">
                                                <option value="Product A"></option>
                                                <option value="Product B"></option>
                                                <option value="Product X"></option>
                                                <option value="Product Y"></option>
                                            </datalist>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Original Price:</label><br>
                                            <input type="number" name="og_price" readonly>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Percent Discount (%):</label><br>
                                            <input type="number" id="percent" name="percent" required>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">New Price:</label><br>
                                            <input type="number" id="newPrice" name="new_price" aria-readonly="true">
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">FROM:</label><br>
                                            <input type="date" id="fromDate" name="from_date" required>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">TO:</label><br>
                                            <input type="date" id="toDate" name="to_date" aria-readonly="true">
                                        </div>

                                    </div>


                                    <div class="input-row">

                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="" id="" cols="20" rows="3"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBtn" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <div class="auto-computations">
                <div class="import-btn">
                    <button id="importpurchase" class="import">
                        <i class="fa fa-download"></i>
                        <span>Import</span>
                    </button>
                </div>
                <div class="export-btn">
                    <button id="exportpurchase" class="export">
                        <i class="fa fa-upload"></i>
                        <span>Export</span>
                    </button>
                </div>
            </div>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>From</th>
                        <th>To</th>
                        <th>New Price</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, product_id, from_date, to_date, new_price FROM on_sale";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['product_id'];?></td>
                                <td><?php echo $row['account_id'];?></td>
                                <td><?php echo $row['amount'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
                <tbody>
                    <!-- Add your data rows here -->
                    <tr>
                        <td>032</td>
                        <td>Juice Blender</td>
                        <td>29-02-2024</td>
                        <td>15-03-2024</td>
                        <td class="td-amount">700,000</td>
                        <td class="td-action">
                            <div class="action">
                                <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                <span class="action-dropdown">
                                    <a href="#" class="view-btn viewBtn">View</a>
                                    <a href="#" class="edit-btn editBtn">Edit</a>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>032</td>
                        <td>Juice Blender</td>
                        <td>29-02-2024</td>
                        <td>15-03-2024</td>
                        <td class="td-amount">750,000</td>
                        <td class="td-action">
                            <div class="action">
                                <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                <span class="action-dropdown">
                                    <a href="#" class="view-btn viewBtn">View</a>
                                    <a href="#" class="edit-btn editBtn">Edit</a>
                                </span>
                            </div>
                        </td>
                    </tr>

                    <!-- Add more rows as needed -->
                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>On-Sale Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">On Sale Code:</span>
                                <figure>856</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title"> Product Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">From:</span>
                                <figure>29-02-2024</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">To:</span>
                                <figure>15-03-2024</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Product Name:</span>
                                <figure>Juice Blender</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">On Sale Percent:</span>
                                <figure>25%</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Original Price:</span>
                                <figure>1,000,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">On Sale Price:</span>
                                <figure>750,000</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>

                        </div>

                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


                    <!--Edit details-->
                    <div class="popup-container editContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>EditOn Sale Details</h2>
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Percent Discount (%):</label><br>
                                            <input type="number" id="percent" name="percent" required>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">New Price:</label><br>
                                            <input type="number" id="newPrice" name="new_price" aria-readonly="true">
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">FROM:</label><br>
                                            <input type="date" id="fromDate" name="from_date" required>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">TO:</label><br>
                                            <input type="date" id="toDate" name="to_date" aria-readonly="true">
                                        </div>

                                    </div>


                                    <div class="input-row">

                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="" id="" cols="20" rows="3"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Account:</label><br>
                            <input list="Accounts" class="datalist-input" id="accountId" name="account_id" autocomplete="off" required>

                            <datalist id="Accounts">
                                <option value="Cash"></option>
                                <option value="Mobile"></option>
                                <option value="Bank"></option>
                            </datalist>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>