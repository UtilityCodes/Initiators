<?php
// admin/purchase-return/get_products_details.php
include '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['product']) && isset($_GET['warehouse'])) {
    $productName = $_GET['product'];
    $warehouseId = $_GET['warehouse'];

    // Fetch product details based on the provided name or barcode and warehouse
    $productDetailsQuery = "SELECT 
                            product.id as id,
                            product.name as name,
                            product.code as code,
                            product.buying_price as buying_price,
                            unit.name as unit_name,
                            stock.quantity as quantity
                        FROM product
                        INNER JOIN unit ON product.unit_id = unit.id
                        INNER JOIN stock ON product.id = stock.product_id
                        WHERE (product.name = '$productName' OR product.code = '$productName') 
                        AND stock.warehouse_id = '$warehouseId'";
    $result = $conn->query($productDetailsQuery);

    if ($result && $result->num_rows > 0) {
        $productDetails = $result->fetch_assoc();

        // Return product details as JSON
        header('Content-Type: application/json');
        echo json_encode($productDetails);
    } else {
        // Product not found
        header("HTTP/1.1 404 Not Found");
        echo json_encode(['error' => 'Product not found']);
    }
} else {
    // Invalid request
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();

