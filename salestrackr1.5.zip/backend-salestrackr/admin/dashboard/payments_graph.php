<?php
// admin/dashboard/payments_graph.php ***
include('../../config.php'); // Include your database connection file

$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

$queryPaymentIn = "SELECT DATE(payments.dates) AS payment_date, SUM(payments.amount) AS total_payment_in
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    JOIN trans_type ON transactions.trans_type_id = trans_type.id
    WHERE trans_type.name = 'Pay-In'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY payment_date
    ORDER BY payment_date";

$resultPaymentIn = $conn->query($queryPaymentIn);

$queryPaymentOut = "SELECT DATE(payments.dates) AS payment_date, SUM(payments.amount) AS total_payment_out
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    JOIN trans_type ON transactions.trans_type_id = trans_type.id
    WHERE trans_type.name = 'Pay-Out'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY payment_date
    ORDER BY payment_date";

$resultPaymentOut = $conn->query($queryPaymentOut);

$dataPaymentIn = array();
while ($row = $resultPaymentIn->fetch_assoc()) {
    $dataPaymentIn[$row['payment_date']] = array(
        'date' => $row['payment_date'],
        'total_payment_in' => $row['total_payment_in']
    );
}

$dataPaymentOut = array();
while ($row = $resultPaymentOut->fetch_assoc()) {
    $dataPaymentOut[$row['payment_date']] = array(
        'date' => $row['payment_date'],
        'total_payment_out' => $row['total_payment_out']
    );
}

// Combine Payment-In and Payment-Out data
$finalData = array();
foreach ($dataPaymentIn as $date => $paymentIn) {
    $finalData[$date] = array(
        'date' => $date,
        'total_payment_in' => $paymentIn['total_payment_in'],
        'total_payment_out' => isset($dataPaymentOut[$date]) ? $dataPaymentOut[$date]['total_payment_out'] : 0
    );
}

// Encode as JSON and output
header('Content-Type: application/json');
echo json_encode(array_values($finalData));
$conn->close();
?>
