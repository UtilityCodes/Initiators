<?php
// admin/dashboard/purchases_graph.php ***
include('../../config.php'); // Include your database connection file

$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

$queryPurchases = "SELECT DATE(payments.dates) AS purchase_date, SUM(payments.amount) AS total_purchases
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name IN ('Purchase')
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY purchase_date
    ORDER BY purchase_date";

$result = $conn->query($queryPurchases);

$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = array(
        'date' => $row['purchase_date'],
        'total_purchases' => $row['total_purchases']
    );
}

header('Content-Type: application/json');
echo json_encode($data);
$conn->close();

