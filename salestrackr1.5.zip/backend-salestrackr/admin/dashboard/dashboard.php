<?php
// admin/dashboard/dashboard.php

include '../../config.php';
include 'balance_cards.php';
include 'card_row1.php';
include 'card_row2.php';


session_start();

?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Dashboard For The Admin';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="dashbody">

            <!--Cash, Bank and Mobile-->
            <div class="dash-accounts">
                <div class="account-flex">

                    <!--The CASH CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Cash</span>
                                <div class="icon">
                                    <i class='bx bx-money' style="color: orange;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($cashBalance, 2); ?></figure>
                        </div>

                    </div>

                    <!--The BANK CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Bank</span>
                                <div class="icon">
                                    <i class='bx bxs-bank' style="color: lightgreen;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($bankBalance, 2); ?></figure>
                        </div>

                    </div>

                    <!--The MOBILE CARD-->
                    <div class="account-cards">

                        <div class="account-heading">
                            <div class="heading-flex">
                                <span class="span-head">Mobile</span>
                                <div class="icon">
                                    <i class='bx bx-mobile' style="color: lightblue;"></i>
                                </div>
                            </div>
                        </div>
                        <div class="account-figure">
                            <figure><?php echo number_format($mobileBalance, 2); ?></figure>
                        </div>

                    </div>

                </div>

            </div>

            <!-- Sales and Purchases Graphs-->
            <div class="graphs graphs-1">
                <div class="graph-flex">

                    <!--Sales Graph-->
                    <div class="canvas canvas-1">
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Sales</div>
                                <form class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date" name="start_sales_graph_date" value="<?php echo $defaultStartDate ?>">
                                    </div>
                                    <div class="to-date">
                                        <input type="date" name="end_sales_graph_date" value="<?php echo $defaultEndDate ?>">
                                    </div>
                                    <div class="date-filter-input" style="display:none">
                                        <button type="button" name="filter_sales_graph">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="salesChart" class="line-bar-graphs"></canvas>
                        </div>

                    </div>

                    <!--Purchases Graphs-->
                    <div class="canvas canvas-2">

                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Purchases</div>
                                <form class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date" value="<?php echo $defaultStartDate ?>">
                                    </div>
                                    <div class="to-date">
                                        <input type="date" value="<?php echo $defaultEndDate ?>">
                                    </div>
                                    <div class="date-filter-input" style="display:none">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="purchaseChart" class="line-bar-graphs"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!--Revenue and purchases Cards-->
            <div class="cards cards-1">

                <div class="card-row-date-filter">
                    <form class="date-filter-card" method="post" action="">
                        <div class="from-date">
                            <input type="date" name="start_card1_date" value="<?php echo $defaultStartDate ?>">
                        </div>
                        <div class="to-date">
                            <input type="date" name="end_card1_date" value="<?php echo $defaultEndDate ?>">
                        </div>
                        <div class="date-filter-input" style="display: none">
                            <button type="button" name="filter_card1_date">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-row card-row-up">
                    <div class="card-row-flex">
                        <!--REVENUE CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Revenue</div>
                            <div class="row-card-figure"><?php echo number_format($totalRevenue); ?></div>
                        </div>
                        <!--SALES RETURN CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Sales Return</div>
                            <div class="row-card-figure"><?php echo number_format($totalSR); ?></div>
                        </div>
                        <!--TOTAL CREDIT-->
                        <div class="row-cards">
                            <div class="row-card-head">Total Debit</div>
                            <div class="row-card-figure"><?php echo number_format($totalDebit); ?></div>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-down">
                    <div class="card-row-flex">
                        <!--PURCHASES CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Purchases</div>
                            <div class="row-card-figure"><?php echo number_format($totalPurchases); ?></div>
                        </div>
                        <!--PURCHASE RETURN CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Purchase Return</div>
                            <div class="row-card-figure"><?php echo number_format($totalPR); ?></div>
                        </div>
                        <!--TOTAL CREDIT-->
                        <div class="row-cards">
                            <div class="row-card-head">Total Credit</div>
                            <div class="row-card-figure"><?php echo number_format($totalCredit); ?></div>
                        </div>
                    </div>
                </div>

            </div>

            <!--Payments and Expenses Graphs-->
            <div class="graphs graphs-2">
                <div class="graph-flex">

                    <!--PAYMENT GRAPH-->
                    <div class="canvas canvas-1">
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Payment</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date" value="<?php echo $defaultStartDate ?>">
                                    </div>
                                    <div class="to-date">
                                        <input type="date" value="<?php echo $defaultEndDate ?>">
                                    </div>
                                    <div class="date-filter-input" style="display:none">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="paymentsChart" class="line-bar-graphs"></canvas>
                        </div>

                    </div>

                    <!--EXPENSES GRAPH-->
                    <div class="canvas canvas-2">
                        
                        <div class="graph-head">
                            <div class="gh-flex">
                                <div class="graph-title">Expenses</div>
                                <div class="graph-date-filter">

                                    <div class="from-date">
                                        <input type="date" id="start_expenses_date" value="<?php echo $defaultStartDate ?>">
                                    </div>
                                    <div class="to-date">
                                        <input type="date" id="end_expenses_date" value="<?php echo $defaultEndDate ?>">
                                    </div>
                                    <div class="date-filter-input" id="filter_expenses" style="display:none">
                                        <button type="button">
                                            <i class="fa fa-filter" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="actual-graph">
                            <canvas id="expensesChart" class="line-bar-graphs"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!--Payment Cards-->
            <div class="cards cards-2">

                <div class="card-row-date-filter">
                    <form class="date-filter-card" action="card_row2.php" method="post">
                        <div class="from-date">
                            <input type="date" name="cards2_from_date" value="<?php echo $defaultStartDate;?>">
                        </div>
                        <div class="to-date">
                            <input type="date" name="cards2_to_date" value="<?php echo $defaultEndDate;?>">
                        </div>
                        <div class="date-filter-input" style="display:none">
                            <button type="submit" name="cards2_date_filter">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                            </button>
                        </div>
                    </form>
                </div>
                <div class="card-row card-row-up">
                    <div class="card-row-flex">
                        <!--PAYMENT-IN-->
                        <div class="row-cards">
                            <div class="row-card-head">Payment-In</div>
                            <div class="row-card-figure"><?php echo number_format($paymentInRow['total_payment_in']); ?></div>
                        </div>
                        <!--PAYMENT-OUT-->
                        <div class="row-cards">
                            <div class="row-card-head">Payment-Out</div>
                            <div class="row-card-figure"><?php echo number_format($paymentOutRow['total_payment_out']); ?></div>
                        </div>
                        <!--CASH-IN-HAND-->
                        <div class="row-cards">
                            <div class="row-card-head">Cash-In-Hand</div>
                            <div class="row-card-figure"><?php echo number_format($cashInHand); ?></div>
                        </div>
                    </div>
                </div>
                <div class="card-row card-row-down">
                    <div class="card-row-flex">
                        <!--EXPENSES CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Expenses</div>
                            <div class="row-card-figure"><?php echo number_format($expenseRow['total_expenses']); ?></div>
                        </div>
                        <!--DRAWINGS CARD-->
                        <div class="row-cards">
                            <div class="row-card-head">Drawings</div>
                            <div class="row-card-figure"><?php echo number_format($drawingsRow['total_drawings']); ?></div>
                        </div>
                        <!--TRANSFER CARD-->
                        <div class="row-cards" style="display:none">
                            <div class="row-card-head">Transfer</div>
                            <div class="row-card-figure">8</div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </section>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

    

    <script>
        // FOR PURCHASES GRAPH
        // Function to fetch data from purchases_graph.php
        async function fetchData() {
            const response = await fetch('purchases_graph.php');
            const data = await response.json();
            return data;
        }

        // Function to create the bar graph
        async function createBarGraph() {
            const data = await fetchData();

            const ctx = document.getElementById('purchaseChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.map(entry => entry.date),
                    datasets: [{
                        label: 'Total Purchases',
                        data: data.map(entry => entry.total_purchases),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { type: 'category', title: { display: true, text: 'Date' } },
                        y: { beginAtZero: true, title: { display: true, text: 'Total Purchases' } }
                    }
                }
            });
        }

        // Call the function to create the bar graph
        createBarGraph();

        // FOR SALES GRAPH
        async function fetchSalesData() {
            const response = await fetch('sales_graph.php');
            const data = await response.json();
            return data;
        }

        async function createSalesGraph() {
            const data = await fetchSalesData();

            const ctx = document.getElementById('salesChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.map(entry => entry.date),
                    datasets: [{
                        label: 'Total Sales',
                        data: data.map(entry => entry.total_sale),
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { type: 'category', title: { display: true, text: 'Date' } },
                        y: { beginAtZero: true, title: { display: true, text: 'Total Sales' } }
                    }
                }
            });
        }

        createSalesGraph();

// FOR PAYMENT GRAPH
async function fetchPaymentData() {
    const response = await fetch('payments_graph.php');
    const data = await response.json();
    return data;
}

async function createPaymentGraph() {
    const data = await fetchPaymentData();

    const ctx = document.getElementById('paymentsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(entry => entry.date),
            datasets: [
                {
                    label: 'Payment-In',
                    data: data.map(entry => entry.total_payment_in),
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderWidth: 1,
                    fill: false
                },
                {
                    label: 'Payment-Out',
                    data: data.map(entry => entry.total_payment_out),
                    borderColor: 'rgba(255, 99, 132, 1)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderWidth: 1,
                    fill: false
                }
            ]
        },
        options: {
            scales: {
                x: { type: 'category', title: { display: true, text: 'Date' } },
                y: { beginAtZero: true, title: { display: true, text: 'Amount' } }
            }
        }
    });
}

createPaymentGraph();



        // FOR EXPENSES GRAPH

        async function fetchExpensesData() {
            const response = await fetch('expenses_graph.php');
            const data = await response.json();
            return data;
        }

        async function createExpensesGraph() {
            const data = await fetchExpensesData();

            const ctx = document.getElementById('expensesChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.map(entry => entry.date),
                    datasets: [{
                        label: 'Total Expenses',
                        data: data.map(entry => entry.total_expenses),
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { type: 'category', title: { display: true, text: 'Date' } },
                        y: { beginAtZero: true, title: { display: true, text: 'Total Expenses' } }
                    }
                }
            });
        }

        createExpensesGraph();



    </script>


      
    

</body>
</html>