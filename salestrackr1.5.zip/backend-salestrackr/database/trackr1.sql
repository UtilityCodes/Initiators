-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2024 at 03:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trackr_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `name`) VALUES
(1, 'CASH'),
(2, 'BANK'),
(3, 'MOBILE'),
(4, 'OTHER');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `code`, `name`, `note`) VALUES
(1, '5657', 'skycrawler', 'the best one'),
(5, '343', 'Raytheon', 'delicate'),
(6, '987', 'Aiolyon', 'No Note'),
(7, '3434', 'BRAND 12', 'DFFF'),
(8, '323232', 'BRAND 333', 'DD'),
(9, '67887', 'BRAND 999', 'FFF'),
(10, '24425', 'LG', 'for electronics'),
(11, 'brand--1710445636', 'SONY', 'No Note'),
(13, 'brand--1710446882', 'HAIER', 'No Note'),
(15, 'brand--1710446956', 'SOLVENT', 'No Note'),
(16, 'brand--1710447059', 'carrier', 'No Note'),
(17, 'brand--1710447104', 'ballglobe', 'sports toys');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `code`, `name`, `note`) VALUES
(1, '767', 'Beer', 'above 12%'),
(2, '98090898', 'category 55', 'fff'),
(3, '3132', 'category hhh', 'd3d3'),
(4, '444', 'laptop', 'vvv'),
(5, '323', 'washers', 'dfgd'),
(6, '33', 'loop-ropes', 'cfc'),
(7, '34334', 'Television', 'electronics'),
(8, 'cate--1710447265', 'stapler-machine', 'No Note'),
(9, 'cate--1710447370', 'TV-Oil', 'for lubricating vents');

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `amount` double NOT NULL,
  `from_customer_id` int(11) NOT NULL,
  `to_customer_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupon_spend`
--

CREATE TABLE `coupon_spend` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `amount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `code`, `name`, `note`, `phone`, `email`, `address`) VALUES
(1, '590', 'Candy', 'No Note', '', '', 'Temeke'),
(2, '223', 'Landy', 'no note', '54545456', 'Tabata', 'land@email.com'),
(3, '432', 'Bugalio', 'pope 2', '09876554432', 'bugalio@email.com', 'Buenos Ares'),
(4, '323', 'Happiness', 'regular', '0712567238', 'euphoria@email.com', 'Kurasini'),
(5, 'cus--1710459857', 'Albert', 'No Note', '07123456783', 'none@email.com', 'No Address');

-- --------------------------------------------------------

--
-- Table structure for table `drawings`
--

CREATE TABLE `drawings` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `note` text NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drawings`
--

INSERT INTO `drawings` (`id`, `code`, `dates`, `warehouse_id`, `account_id`, `amount`, `note`, `user_id`) VALUES
(4, 'draw--1710383945-219', '2024-03-14', 1, 2, 70000, 'No Note', 4),
(5, 'draw--1710450277-815', '2024-03-14', 1, 2, 85000, 'No Note', 4);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `amount` double NOT NULL,
  `type_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `code`, `dates`, `note`, `amount`, `type_id`, `account_id`, `warehouse_id`, `user_id`) VALUES
(7, 'exp--1710377852-682', '2024-03-14', 'No Note', 16000, 3, 1, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `on_sale`
--

CREATE TABLE `on_sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `original_price` double NOT NULL,
  `percent_discount` double NOT NULL,
  `new_price` double NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `code`, `amount`, `account_id`, `trans_id`, `warehouse_id`, `user_id`, `pay_code`, `dates`, `note`) VALUES
(57, 'pur--1710340785', 40000, 1, 2, 2, 4, 'pay-1710340785-063', '2024-03-13', 'GRACIOUS'),
(58, 'pur--1710340785', 80000, 2, 2, 2, 4, 'pay-1710340785-063', '2024-03-13', 'GRACIOUS'),
(59, 'pur--1710340931', 90000, 1, 2, 2, 4, 'pay-1710340931-109', '2024-03-13', 'YES'),
(60, 'pur--1710344089-865', 240000, 1, 2, 2, 4, 'pay-1710344089-171', '2024-03-13', 'mind'),
(61, 'pur--1710344136-254', 45000, 1, 2, 2, 4, 'pay-1710344136-805', '2024-03-13', 'all'),
(62, 'sale--1710344398-416', 50000, 1, 1, 2, 4, 'pay--1710344398-067', '2024-03-13', 'fire nation'),
(63, 'sale--1710344398-416', 500000, 2, 1, 2, 4, 'pay--1710344398-067', '2024-03-13', 'fire nation'),
(64, 'pr--1710348788-433', 28000, 1, 4, 2, 4, 'pay--1710348788-503', '2024-03-13', 'racially'),
(65, 'sr--1710349596-316', 20000, 1, 5, 2, 4, 'pay--1710349596-365', '2024-03-13', 'hm?'),
(66, 'pur--1710374955-131', 40000, 3, 2, 1, 4, 'pay-1710374955-773', '2024-03-14', 'care'),
(68, 'exp--1710377852-682', 16000, 1, 6, 1, 4, 'pay--1710377852-075', '2024-03-14', 'No Note'),
(69, 'pur--1710380370-985', 120000, 2, 2, 1, 4, 'pay-1710380370-957', '2024-03-14', 'bank baby!'),
(70, 'sale--1710380444-078', 425000, 1, 1, 2, 4, 'pay--1710380444-492', '2024-03-14', 'cash baby!!!'),
(71, 'sale--1710380987-881', 60000, 3, 1, 2, 4, 'pay--1710380987-517', '2024-03-14', 'mobile money'),
(72, 'sale--1710381172-892', 70000, 2, 1, 1, 4, 'pay--1710381172-556', '2024-03-14', 'anadaiwa'),
(73, 'draw--1710383945-219', 70000, 2, 7, 1, 4, 'pay--1710383945-232', '2024-03-14', 'No Note'),
(74, 'pur--1710447587-696', 35000, 1, 2, 1, 4, 'pay-1710447587-325', '2024-03-14', 'all cash'),
(75, 'sale--1710449921-714', 20000, 1, 1, 1, 4, 'pay--1710449921-884', '2024-03-14', 'nice trackrecord'),
(76, 'draw--1710450277-815', 85000, 2, 7, 1, 4, 'pay--1710450277-976', '2024-03-14', 'No Note'),
(78, 'pr--1710451297-522', 13000, 1, 4, 2, 4, 'pay--1710451297-133', '2024-03-14', 'lets see if it works'),
(79, 'sr--1710451833-250', 25000, 2, 5, 2, 4, 'pay--1710451833-367', '2024-03-14', 'azula'),
(80, 'pur--1710464592-665', 60000, 2, 2, 3, 5, 'pay-1710464592-653', '2024-03-15', 'had no money'),
(81, 'sale--1710464791-705', 30000, 1, 1, 3, 4, 'pay--1710464791-057', '2024-03-15', 'good money'),
(82, 'sale--1710464791-705', 30000, 2, 1, 3, 4, 'pay--1710464791-057', '2024-03-15', 'good money');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `buying_price` double NOT NULL,
  `selling_price` double NOT NULL,
  `unit_id` int(11) NOT NULL,
  `min_q` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `code`, `name`, `note`, `brand_id`, `category_id`, `buying_price`, `selling_price`, `unit_id`, `min_q`) VALUES
(6, '313', 'violin', 'hbkadhj', 8, 3, 24000, 75000, 1, 10),
(7, '1121', 'kater', 'bfjf', 6, 6, 13000, 30000, 3, 8),
(8, '2443', 'revolver-gun', 'fgdgf', 5, 6, 14000, 55000, 1, 5),
(9, 'q3431', 'lg-tv-inch-30', 'black', 10, 7, 120000, 450000, 1, 4),
(10, 'prod--1710447515', 'TV-Oil-ml500', 'trial product', 15, 9, 12000, 25000, 3, 10);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `lpo_no` int(50) DEFAULT NULL,
  `proforma_no` int(50) DEFAULT NULL,
  `dn_no` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `code`, `dates`, `supplier_id`, `product_id`, `warehouse_id`, `quantity`, `price`, `user_id`, `lpo_no`, `proforma_no`, `dn_no`) VALUES
(53, 'pur--1710340785', '2024-03-13', 2, 6, 2, 1, 24000, 4, 0, 0, 0),
(54, 'pur--1710340785', '2024-03-13', 2, 9, 2, 1, 120000, 4, 0, 0, 0),
(55, 'pur--1710340931', '2024-03-13', 1, 7, 2, 3, 13000, 4, 0, 0, 0),
(56, 'pur--1710340931', '2024-03-13', 1, 8, 2, 5, 14000, 4, 0, 0, 0),
(57, 'pur--1710344089-865', '2024-03-13', 1, 9, 2, 2, 120000, 4, 0, 0, 0),
(58, 'pur--1710344136-254', '2024-03-13', 1, 7, 2, 4, 13000, 4, 0, 0, 0),
(59, 'pur--1710374955-131', '2024-03-14', 2, 6, 1, 2, 24000, 4, 0, 0, 0),
(60, 'pur--1710380370-985', '2024-03-14', 1, 9, 1, 1, 120000, 4, 0, 0, 0),
(61, 'pur--1710447587-696', '2024-03-14', 1, 10, 1, 3, 12000, 4, 0, 0, 0),
(62, 'pur--1710464592-665', '2024-03-15', 1, 7, 3, 5, 13000, 5, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_return`
--

CREATE TABLE `purchase_return` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_return`
--

INSERT INTO `purchase_return` (`id`, `code`, `dates`, `supplier_id`, `product_id`, `warehouse_id`, `quantity`, `user_id`) VALUES
(3, 'pr--1710348409', '2024-03-13', 1, 7, 2, 2, 4),
(4, 'pr--1710348788-433', '2024-03-13', 2, 8, 2, 2, 4),
(6, 'pr--1710451297-522', '2024-03-14', 1, 7, 2, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Manager'),
(3, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `lpo_no` int(50) DEFAULT NULL,
  `proforma_no` int(50) DEFAULT NULL,
  `dn_no` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`id`, `code`, `dates`, `customer_id`, `product_id`, `warehouse_id`, `quantity`, `price`, `user_id`, `lpo_no`, `proforma_no`, `dn_no`) VALUES
(9, 'sale--1710343833-068', '2024-03-13', 3, 7, 2, 2, 30000, 4, 0, 0, 0),
(10, 'sale--1710344398-416', '2024-03-13', 3, 8, 2, 2, 55000, 4, 0, 0, 0),
(11, 'sale--1710344398-416', '2024-03-13', 3, 9, 2, 1, 450000, 4, 0, 0, 0),
(12, 'sale--1710380444-078', '2024-03-14', 2, 9, 2, 1, 450000, 4, 0, 0, 0),
(13, 'sale--1710380987-881', '2024-03-14', 2, 7, 2, 2, 30000, 4, 0, 0, 0),
(14, 'sale--1710381172-892', '2024-03-14', 4, 6, 1, 1, 75000, 4, 0, 0, 0),
(15, 'sale--1710449921-714', '2024-03-14', 4, 10, 1, 1, 25000, 4, 0, 0, 0),
(16, 'sale--1710464791-705', '2024-03-15', 4, 7, 3, 2, 30000, 4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sale_return`
--

CREATE TABLE `sale_return` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_return`
--

INSERT INTO `sale_return` (`id`, `code`, `dates`, `customer_id`, `product_id`, `warehouse_id`, `quantity`, `user_id`) VALUES
(5, 'sr--1710349596-316', '2024-03-13', 2, 7, 2, 2, 4),
(6, 'sr--1710451833-250', '2024-03-14', 2, 8, 2, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `code`, `name`, `note`) VALUES
(1, '7587', 'Grocery Loading', 'not less than 2000'),
(2, '2332', 'Wheel Alignment', 'silver general');

-- --------------------------------------------------------

--
-- Table structure for table `service_sale`
--

CREATE TABLE `service_sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES
(47, 9, 2, 1),
(48, 7, 2, 2),
(49, 8, 2, 3),
(50, 6, 1, 1),
(51, 9, 1, 1),
(52, 10, 1, 2),
(53, 7, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `code`, `name`, `note`, `phone`, `email`, `address`) VALUES
(1, '198', 'Bituso General', 'no note', '0765098765', 'bituso@email.com', 'Posta'),
(2, '77u', 'General-Electronics', 'original', '0765986532', 'g.e.tz@email.com', 'Posta Mpya');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `trans_type_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `name`, `trans_type_id`) VALUES
(1, 'Sale', 1),
(2, 'Purchase', 2),
(3, 'Service_sale', 1),
(4, 'Purchase_return', 1),
(5, 'Sale_return', 2),
(6, 'Expenses', 2),
(7, 'Drawings', 2),
(8, 'Coupon', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_type`
--

CREATE TABLE `trans_type` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trans_type`
--

INSERT INTO `trans_type` (`id`, `name`) VALUES
(1, 'Pay-In'),
(2, 'Pay-Out');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `code`, `name`, `note`) VALUES
(1, '5345', 'Transport', 'including in-house shipping'),
(2, '5345', 'Umeme', 'electric bill'),
(3, '2323', 'Usafi', 'toilet and warehouse cleanliness '),
(4, '4532', 'Food', 'food for staff');

-- --------------------------------------------------------

--
-- Table structure for table `unique_activity`
--

CREATE TABLE `unique_activity` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount` double NOT NULL,
  `actual_amount` double NOT NULL,
  `trans_id` int(11) NOT NULL,
  `dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unique_activity`
--

INSERT INTO `unique_activity` (`id`, `code`, `discount`, `actual_amount`, `trans_id`, `dates`) VALUES
(23, 'pur--1710340785', 4000, 140000, 2, '2024-03-13'),
(24, 'pur--1710340931', 9000, 100000, 2, '2024-03-13'),
(25, 'pur--1710344089-865', 0, 240000, 2, '2024-03-13'),
(26, 'pur--1710344136-254', 2000, 50000, 2, '2024-03-13'),
(27, 'sale--1710344398-416', 10000, 550000, 1, '2024-03-13'),
(28, 'pr--1710348788-433', 0, 28000, 4, '2024-03-13'),
(29, 'sr--1710349596-316', 0, 26000, 5, '2024-03-13'),
(30, 'pur--1710374955-131', 0, 48000, 2, '2024-03-14'),
(31, 'pur--1710380370-985', 0, 120000, 2, '2024-03-14'),
(32, 'sale--1710380444-078', 25000, 425000, 1, '2024-03-14'),
(33, 'sale--1710380987-881', 0, 60000, 1, '2024-03-14'),
(34, 'sale--1710381172-892', 0, 75000, 1, '2024-03-14'),
(35, 'pur--1710447587-696', 1000, 35000, 2, '2024-03-14'),
(36, 'sale--1710449921-714', 0, 25000, 1, '2024-03-14'),
(38, 'pr--1710451297-522', 0, 13000, 4, '2024-03-14'),
(39, 'sr--1710451833-250', 3000, 25000, 5, '2024-03-14'),
(40, 'pur--1710464592-665', 5000, 60000, 2, '2024-03-15'),
(41, 'sale--1710464791-705', 0, 60000, 1, '2024-03-15');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`) VALUES
(1, 'Piece'),
(2, 'Kg'),
(3, 'Litre'),
(4, 'Boxes');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `passcode` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `code`, `passcode`, `role_id`, `phone`, `email`, `warehouse_id`, `note`) VALUES
(1, 'Aladin', '222', '123', 1, '0789234519', 'emarich@gmail.com', 1, 'no note'),
(2, 'Beliza', 'b45', '56Beliza2000', 2, '0789231465', 'belz@email.com', 1, 'from Lazio'),
(3, 'Luka ', 'luk234', 'lukadoncic2024', 3, '18004587610', 'doncic@email.com', 1, 'Indiana Pacers'),
(4, 'Masatu', '36', '123', 1, '0695880848', 'masatu@email.com', 2, 'no desc'),
(5, 'Hamoud', '233d', '123', 2, '07123456787', 'jp@icloud.com', 3, 'okay'),
(6, 'jerry', '334', '123', 3, '8378327', 'salim@gmail.com', 1, 'none');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `code`, `name`, `address`, `note`) VALUES
(1, '222', 'Warehouse-Kkoo', 'Kariakoo', 'No Note'),
(2, '890', 'WH-Sinza', 'Sinza', 'mori'),
(3, 'wh-bs5', 'Baraza-WH', 'SalaSala', 'main');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon`
--
ALTER TABLE `coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon_spend`
--
ALTER TABLE `coupon_spend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drawings`
--
ALTER TABLE `drawings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `on_sale`
--
ALTER TABLE `on_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_return`
--
ALTER TABLE `purchase_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_return`
--
ALTER TABLE `sale_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_sale`
--
ALTER TABLE `service_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trans_type`
--
ALTER TABLE `trans_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unique_activity`
--
ALTER TABLE `unique_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `coupon`
--
ALTER TABLE `coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `coupon_spend`
--
ALTER TABLE `coupon_spend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `drawings`
--
ALTER TABLE `drawings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `on_sale`
--
ALTER TABLE `on_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `purchase_return`
--
ALTER TABLE `purchase_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sale_return`
--
ALTER TABLE `sale_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_sale`
--
ALTER TABLE `service_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `transfer`
--
ALTER TABLE `transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_type`
--
ALTER TABLE `trans_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `unique_activity`
--
ALTER TABLE `unique_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
