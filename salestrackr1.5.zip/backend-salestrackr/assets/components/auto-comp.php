            <div class="auto-computations" style="display:none;">
                <div class="import-btn">
                    <button id="importBrand" class="import">
                        <i class="fa fa-download"></i>
                        <span>Import</span>
                    </button>
                </div>
                <div class="export-btn">
                    <button id="exportBrand" class="export">
                        <i class="fa fa-upload"></i>
                        <span>Export</span>
                    </button>
                </div>
            </div>