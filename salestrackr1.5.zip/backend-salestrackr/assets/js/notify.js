document.addEventListener("DOMContentLoaded", function() {
    const notificationToggle = document.getElementById("notificationToggle");
    const notificationDropdown = document.getElementById("notificationDropdown");

    notificationToggle.addEventListener("click", function(event) {
        event.stopPropagation(); // Prevents the click event from reaching the window

        // Toggle the dropdown visibility directly
        notificationDropdown.style.display = (notificationDropdown.style.display === "block") ? "none" : "block";
    });

    // Close the dropdown if the user clicks outside of it
    window.addEventListener("click", function() {
        notificationDropdown.style.display = "none";
    });

    // Prevent the dropdown from closing when clicked inside
    notificationDropdown.addEventListener("click", function(event) {
        event.stopPropagation(); // Prevents the click event from reaching the window
    });
});

