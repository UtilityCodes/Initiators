<?php
// admin/product-details/purchases.php
// Include the database connection file
include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session
$warehouseId = $_SESSION['warehouse_id'];
$user_id = $_SESSION['user_id'];


// Close the database connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Product Details | Purchases';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">

                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Purchase Code</th>
                        <th>Product Code</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql =  "SELECT 
                                purchase.id as id,
                                purchase.dates as dates,
                                purchase.code as p_code,
                                product.code as barcode,
                                product.name as pro_name,
                                warehouse.name AS wh_name,
                                purchase.quantity as quantity 
                            FROM purchase
                            INNER JOIN product ON purchase.product_id = product.id
                            INNER JOIN warehouse ON purchase.warehouse_id = warehouse.id
                            WHERE purchase.warehouse_id = '$warehouseId'
                            AND purchase.quantity > 0
                            ORDER BY purchase.id desc ";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['p_code'];?></td>
                                <td class="td-action"><?php echo $row['barcode'];?></td>
                                <td class="td-action"><?php echo $row['pro_name'];?></td>
                                <td class="td-action"><?php echo $row['quantity'];?></td>
                                <!-- <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                        </span>
                                    </div>
                                </td> -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Payment Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date:</span>
                                <figure>12-03-2024</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Transaction-type:</span>
                                <figure>Sales</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Transaction-Code:</span>
                                <figure>S-221</figure>
                            </div>
                        </div>
                        <div class="view-div">

                            <div class="div-1">
                                <span class="fixed-title">Account:</span>
                                <figure>Bank</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Warehouse:</span>
                                <figure>WH-3</figure>
                            </div>

                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Amount:</span>
                                <figure>500,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>

                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
      
    

</body>
</html>