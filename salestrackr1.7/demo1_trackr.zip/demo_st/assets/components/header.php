
        
        <header class="header-mp">
            <div class="header-flex">
                <div class="burger left" id="burger-icon"><i class="fa fa-bars"></i></div>
                <div class="middle">
                    <!-- <div class="timestamp">Tuesday, February 6, 2024 at 4:24:00 PM</div> -->
                    <div class="profile">
                        <span class="user"><?php echo $_SESSION['user_name']; ?>
                            <i class="fa fa-chevron-down"></i></span>
                        <div class="user-dropdown">
                            <a href="../../logout.php">Log-out</a>
                        </div>
                    </div>
                </div>
                <div class="right" style="display: none;">
                    <span class="notify" style="display: none;">
                        <a href="">
                            <i class="fa fa-bell"></i>
                            <div class="digit">1</div>
                        </a>
                    </span>
                    <span class="pos-btn"><button>POS</button></span>
                    
                </div>
            </div>
            
        </header>