<nav id="sidebar">
        <header class="left-header">
            <div class="nav-header">
                <img src="../../assets/images/st-logo.jpg" alt="">
                <span>SalesTrackr</span>
                <div class="close"><i class="fa fa-times"></i></div>
            </div>
        </header>
        
        <ul class="side-list">
            <!-- <li><a href="../../admin/dashboard/dashboard.php"><i class="fa fa-th"></i>Dashboard</a></li> -->
            <!-- <li><a href="" class="main-menu"><i class="fa fa-pencil-square-o"></i>Register</a>
                <ul class="sub-menu">
                    <li><a href="../../manager/brand/view.php"><i class="fa fa-copyright"></i>Brand</a></li>
                    <li><a href="../../manager/category/view.php"><i class="fa fa-sitemap"></i>Category</a></li>
                    <li><a href="../../manager/product/view.php"><i class="fa fa-television"></i>Product</a></li>
                    <li><a href="../../admin/service/view.php"><i class="fa fa-motorcycle"></i>Service</a></li>
                </ul>
            </li> -->
            <!-- <li><a href="" class="main-menu"><i class="fa fa-credit-card"></i>Purchases</a>
                <ul class="sub-menu">
                    <li><a href="../../manager/purchases/add.php"><i class="fa fa-plus"></i>Add Purchases</a></li>
                    <li><a href="../../manager/purchases/view.php"><i class="fa fa-list-ol"></i>Purchase List</a></li>
                    <li><a href="../../manager/product-details/purchases.php"><i class="bx bxs-shopping-bag"></i>Product Details</a></li>
                    <li><a href="../../manager/payment-details/purchases.php"><i class="bx bxs-credit-card"></i>Payment Details</a></li>
                </ul>
            </li> -->
            <!-- <li><a href="../../manager/manage-stock/view.php"><i class="bx bxs-box"></i>Stock</a></li> -->
            <li><a href="" class="main-menu"><i class="fa fa-shopping-cart"></i>Sales</a>
                <ul class="sub-menu">
                    <li><a href="../../staff/sales/add.php"><i class="fa fa-plus"></i>Add Sales</a></li>
                    <li><a href="../../staff/sales/view.php"><i class="fa fa-list-ol"></i>Sale List</a></li>
                    <li><a href="../../staff/product-details/sales.php"><i class="bx bxs-shopping-bag"></i>Product Details</a></li>
                    <li><a href="../../staff/payment-details/sales.php"><i class="bx bxs-credit-card"></i>Payment Details</a></li>
                    <!-- <li><a href="../../admin/service-sale/add.php"><i class="fa fa-plus"></i>Add Service Sale</a></li>
                    <li><a href="../../admin/service-sale/view.php"><i class="fa fa-list-ol"></i>Service Sale List</a></li> -->
                    <!-- <li><a href="../../admin/coupon/view.php"><i class='bx bxs-coupon'></i>Coupon</a></li> -->
                </ul>
            </li>
            <!-- <li><a href="#"><i class="fa fa-quote-right"></i>Quotation</a></li> -->
            <li><a href="" class="main-menu"><i class="fa fa-train"></i></i>Transactions</a>
                <ul class="sub-menu">
                    <li><a href="../../staff/payment/view.php"><i class='bx bxs-wallet'></i>Payments</a></li>
                    <!-- <li><a href="../../manager/drawings/view.php"><i class='bx bx-money-withdraw'></i>Drawings</a></li> -->
                </ul>
            </li>
            <!-- <li><a href="../../admin/on-sale/view.php"><i class='bx bxs-discount'></i>On Sale</a></li> -->

            <!-- <li><a href="" class="main-menu"><i class="fa fa-undo"></i>Returns</a>
                <ul class="sub-menu">
                    <li><a href="../../manager/purchase-return/add.php"><i class="fa fa-plus"></i>Add P Returns</a></li>
                    <li><a href="../../manager/purchase-return/view.php"><i class="fa fa-forward"></i>Purchase Returns</a></li>
                    <li><a href="../../manager/product-details/purchase_returns.php"><i class="bx bxs-shopping-bag"></i>Pr Product Details</a></li>
                    <li><a href="../../manager/payment-details/purchase_returns.php"><i class="bx bxs-credit-card"></i>Pr Pay Details</a></li>
                    <li><a href="../../manager/sale-return/add.php"><i class="fa fa-plus"></i>Add S Returns</a></li>
                    <li><a href="../../manager/sale-return/view.php"><i class="fa fa-backward"></i>Sale Returns</a></li>
                    <li><a href="../../manager/product-details/sale_returns.php"><i class="bx bxs-shopping-bag"></i>Sr Product Details</a></li>
                    <li><a href="../../manager/payment-details/sale_returns.php"><i class="bx bxs-credit-card"></i>Sr Pay Details</a></li>
                </ul>
            </li> -->
           
            <!-- <li><a href="" class="main-menu"><i class="fa fa-exchange"></i>Transfer</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/transfer/add.php"><i class="fa fa-plus"></i>Add Transfer</a></li>
                    <li><a href="../../admin/transfer/view.php"><i class="fa fa-list-ol"></i>Transfer List</a></li>
                    
                </ul>
            </li> -->
            <li><a href="" class="main-menu"><i class="fa fa-users"></i>People</a>
                <ul class="sub-menu">
                    <li><a href="../../staff/customer/view.php"><i class="fa fa-user"></i>Customer</a></li>
                    <!-- <li><a href="../../manager/supplier/view.php"><i class="fa fa-user-o"></i>Supplier</a></li> -->
                    <!-- <li><a href="../../admin/user/view.php"><i class="fa fa-user-circle-o"></i>User</a></li> -->
                </ul>
            </li>
            
            <!-- <li><a href="" class="main-menu"><i class="fa fa-money"></i>Expenses</a>
                <ul class="sub-menu">
                    <li><a href="../../manager/type/view.php"><i class="fa fa-plus"></i>Type</a></li>
                    <li><a href="../../manager/expenses/view.php"><i class="fa fa-money"></i>Expenses</a></li>
                    
                </ul>
            </li> -->
            <!-- <li><a href="../../admin/warehouse/view.php"><i class="fa fa-building"></i>Warehouses</a></li> -->
        </ul>           
    </nav>
            