    // Function to initialize DataTable
    $(document).ready(function() {
        $('#view-table').DataTable({
            "order": [[0, "desc"]] // Sort by the first column (index 0) in descending order
        });
    });
    