<?php
// admin/product/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

// Retrieve brand data for dropdown
$brand_query = "SELECT id, name FROM brand";
$brand_result = $conn->query($brand_query);
$brands = $brand_result->fetch_all(MYSQLI_ASSOC);

// Retrieve category data for dropdown
$category_query = "SELECT id, name FROM category";
$category_result = $conn->query($category_query);
$categories = $category_result->fetch_all(MYSQLI_ASSOC);

// Retrieve unit data for dropdown
$unit_query = "SELECT id, name FROM unit";
$unit_result = $conn->query($unit_query);
$units = $unit_result->fetch_all(MYSQLI_ASSOC);


if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT 
               product.id as product_id,
               product.name as name,
               product.code as code,
               brand.name as brand,
               category.name as category,
               product.selling_price as sp,
               product.buying_price as bp,
               unit.name as unit,
               product.min_q as min,
               product.note as note,
               SUM(stock.quantity) as stock
            FROM product
            JOIN brand ON product.brand_id = brand.id
            JOIN category ON product.category_id = category.id
            JOIN unit ON product.unit_id = unit.id
            JOIN stock ON product.id = stock.product_id
            WHERE product.id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){     
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $brand = $row['brand'];
            $category = $row['category'];
            $unit = $row['unit'];
            $stock = $row['stock'];
            $min = $row['min'];
            $bp = number_format($row['bp']);
            $sp = number_format($row['sp']);
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Products';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="productPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>
                <div class="stock-btn" style="display:none">
                    <button type="button" id="productStockFilterPop" class="add-btn">STOCK</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Buying Price</th>
                        <th>Selling Price</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT id, code, name, buying_price as bp, selling_price as sp, note FROM product";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['bp']);?></td>
                                <td class="td-amount"><?php echo number_format($row['sp']);?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn productViewPop">View</a>
                                            <a href="#" class="edit-btn productEditPop">Edit</a>
                                           
                                            <a href="#" class="filter-btn productTransFilterPop">Transactions</a>
                                            <a href="#">Print Barcode</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container productViewContainer" id="productViewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Product Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure><?php echo $name ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Brand:</span>
                                <figure><?php echo $brand ?>t</figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Category:</span>
                                <figure><?php echo $category ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Selling Price:</span>
                                <figure><?php echo $sp ?></figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Buying Price:</span>
                                <figure><?php echo $bp ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Unit:</span>
                                <figure><?php echo $unit ?></figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Alert Quantity:</span>
                                <figure><?php echo $min ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note ?></figure>
                            </div>
                            <div class="div-1">
                                <span class="fixed-title">Stock:</span>
                                <figure><?php echo $stock ?></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button id="closeProductView" class="close-btn closeProductView">CLOSE</button>
                            </a>
                            
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>




