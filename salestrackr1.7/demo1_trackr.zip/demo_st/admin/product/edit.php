<?php
// admin/product/edit.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

// Retrieve brand data for dropdown
$brand_query = "SELECT id, name FROM brand";
$brand_result = $conn->query($brand_query);
$brands = $brand_result->fetch_all(MYSQLI_ASSOC);

// Retrieve category data for dropdown
$category_query = "SELECT id, name FROM category";
$category_result = $conn->query($category_query);
$categories = $category_result->fetch_all(MYSQLI_ASSOC);

// Retrieve unit data for dropdown
$unit_query = "SELECT id, name FROM unit";
$unit_result = $conn->query($unit_query);
$units = $unit_result->fetch_all(MYSQLI_ASSOC);

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    $brandId = $_POST['brand_id'];
    $categoryId = $_POST['category_id'];
    $unitId = $_POST['unit_id'];
    $bp = $_POST['bp'];
    $sp = $_POST['sp'];
    $min = $_POST['min_q'];

    $sql = "UPDATE `product` SET `code` = '$code', `name` = '$name', `note` = '$note', `brand_id` = '$brandId', `category_id` = '$categoryId', `unit_id` = '$unitId', `buying_price` = '$bp', `selling_price` = '$sp', `min_q` = '$min' WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT 
                product.id as id,
                product.code as code,
                product.name as name,
                product.note as note,
                brand.id as brand_id,
                brand.name as brand,
                category.id as category_id,
                category.name as category,
                unit.id as unit_id,
                unit.name as unit,
                buying_price as bp,
                selling_price as sp,
                min_q as min 
            FROM product
            JOIN brand ON product.brand_id = brand.id
            JOIN category ON product.category_id = category.id
            JOIN unit ON product.unit_id = unit.id
            WHERE product.id = '$viewId' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $id = $row['id'];
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $brand = $row['brand'];
            $category = $row['category'];
            $unit = $row['unit'];
            $bp = $row['bp'];
            $sp = $row['sp'];
            $min = $row['min'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Edit Product Details';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="productPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    

                </div>
                <!-- <div class="stock-btn" style="display:none">
                    <button type="button" id="productStockFilterPop" class="add-btn">STOCK</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Buying Price</th>
                        <th>Selling Price</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT id, code, name, buying_price as bp, selling_price as sp, note FROM product";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['bp']);?></td>
                                <td class="td-amount"><?php echo number_format($row['sp']);?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn productViewPop">View</a>
                                            <a href="#" class="edit-btn productEditPop">Edit</a>
                                           
                                            <a href="#" class="filter-btn productTransFilterPop">Transactions</a>
                                            <a href="#">Print Barcode</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for brand view-->
    <div class="edit-pop">
        <div class="popup-container productEditContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">
    
                    <form action="" class="sub-form horizontal-form" method="post">
                        <div class="form-input form-heading">
                            <h2>Edit Product Details</h2>
                        </div>
                        <input type="hidden" name="view_id" value="<?php echo $id;?>">
                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="">Name:</label><br>
                                <input type="text" name="name" value="<?php echo $name;?>">
                            </div>

                            <div class="form-input text-input">
                                <label for="">Code:</label><br>
                                <input type="text" name="code" value="<?php echo $code;?>">
                            </div>

                        </div>

                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="categoryId">Category:</label><br>
                                <select id="categoryId" name="category_id">
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" <?php if ($category['id'] == $id) echo 'selected'; ?>><?php echo $category['name']; ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                            </div>
                            <div class="form-input text-input">
                                <label for="brandId">Brand:</label><br>
                                <select id="brandId" name="brand_id">
                                    <?php foreach ($brands as $brand): ?>
                                        <option value="<?php echo $brand['id']; ?>" <?php if ($brand['id'] == $id) echo 'selected'; ?>><?php echo $brand['name']; ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                            </div>

                        </div>

                        <div class="input-row">
                            
                            <div class="form-input text-input">
                                <label for="">Buying Price:</label><br>
                                <input type="number" name="bp" value="<?php echo $bp;?>">
                            </div>

                            <div class="form-input text-input">
                                <label for="">Selling Price:</label><br>
                                <input type="number" name="sp" value="<?php echo $sp;?>">
                            </div>

                        </div>
                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="unitId">Unit:</label><br>
                                <select id="unitId" name="unit_id" required>
                                    <?php foreach ($units as $unit): ?>
                                        <option value="<?php echo $unit['id']; ?>" <?php if ($unit['id'] == $id) echo 'selected'; ?>><?php echo $unit['name']; ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                            </div>

                            <div class="form-input text-input">
                                <label for="">Alert Quantity:</label><br>
                                <input type="number" name="min_q" value="<?php echo $min;?>">
                            </div>

                        </div>
                        <div class="input-row">
                            
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="note"><?php echo $note;?></textarea>
                        </div>
                        </div>

                        <div class="form-btns">
                            <div class="close-btn" style="display:none">
                                <button id="closeProductEdit" class="close-btn closeProductEdit">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button name="update" class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>

    <?php
    include('../../assets/components/scripts-1.php');
    ?>
    

</body>
</html>



    <?php }else{
        header('location: view.php');
    }
}

?>

