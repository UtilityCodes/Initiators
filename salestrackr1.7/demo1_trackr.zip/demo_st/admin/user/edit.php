<?php
// admin/user/edit.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

// Retrieve role data for dropdown
$role_query = "SELECT id, name FROM role";
$role_result = $conn->query($role_query);
$roles = $role_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    $passcode = $_POST['passcode'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $warehouseId = $_POST['warehouse_id'];
    $roleId = $_POST['role_id'];

    $sql = "UPDATE `user` SET `code` = '$code', `name` = '$name', `note` = '$note', `passcode` = '$passcode', `phone` = '$phone', `email` = '$email', `warehouse_id` = '$warehouseId', `role_id` = '$roleId' WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT 
               user.id as id,
               user.code as code,
               user.name as name,
               user.note as note,
               passcode,
               phone,
               email,
               warehouse.name as wh,
               role.name as role
            FROM user
            JOIN role ON user.role_id = role.id
            JOIN warehouse ON user.warehouse_id = warehouse.id
            WHERE user.id = '$viewId' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $id = $row['id'];
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $passcode = $row['passcode'];
            $phone = $row['phone'];
            $email = $row['email'];
            $wh = $row['wh'];
            $role = $row['role'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Edit | Users';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>

            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Warehouse</th> 
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT
                                user.id as id,
                                user.code as code, 
                                user.name as name, 
                                phone,
                                passcode,
                                warehouse.name as wh,
                                role.name as role_name, 
                                email 
                                FROM user
                                INNER JOIN role ON user.role_id = role.id
                                INNER JOIN warehouse ON user.warehouse_id = warehouse.id
                                ORDER BY user.id DESC";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action"><?php echo $row['role_name'];?></td>
                                <td class="td-action"><?php echo $row['wh'];?></td>
                                
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>

    </section>

    <!--Edit-->
    <div class="edit-pop">
        <div class="popup-container productEditContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">
    
                    <form class="sub-form horizontal-form" method="post">
                        <div class="form-input form-heading">
                            <h2>Edit User Details</h2>
                        </div>
                        <input type="hidden" name="view_id" value="<?php echo $id;?>">
                        <div class="input-row">
            
                            <div class="form-input text-input">
                                <label for="">Name:</label><br>
                                <input type="text" name="name" value="<?php echo $name;?>">
                            </div>
            
                            <div class="form-input text-input">
                                <label for="">Code:</label><br>
                                <input type="text" name="code" value="<?php echo $code;?>">
                            </div>
            
                        </div>

                                    
                        <div class="input-row">

                                        
                            <div class="form-input text-input">
                                <label for="">Password:</label><br>
                                <input type="text" name="passcode" value="<?php echo $passcode;?>">
                            </div>

                            <div class="form-input text-input">
                                <label for="">Role:</label><br>
                                <select id="roleId" name="role_id">
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?php echo $role['id']; ?>" <?php if ($role['id'] == $id) echo 'selected'; ?>><?php echo $role['name']; ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                            </div>


                        </div>
            
                        <div class="input-row">
                                        
                            <div class="form-input text-input">
                                <label for="">Phone no.:</label><br>
                                <input type="number" name="phone" value="<?php echo $phone;?>">
                            </div>
            
                            <div class="form-input text-input">
                                <label for="">Email:</label><br>
                                <input type="text" name="email" value="<?php echo $email;?>">
                            </div>
            
                        </div>

                        <div class="input-row">

                            <div class="form-input text-input">
                                <label for="">Warehouse:</label><br>
                                <select id="warehouseId" name="warehouse_id">
                                    <?php foreach ($warehouses as $warehouse): ?>
                                        <option value="<?php echo $warehouse['id']; ?>" <?php if ($warehouse['id'] == $id) echo 'selected'; ?>><?php echo $warehouse['name']; ?></option>
                                    <?php endforeach; ?>
                                </select><br>
                            </div>
                                        
                            <div class="form-input note-input">
                                <label for="">Description</label><br>
                                <textarea name="note"><?php echo $note;?></textarea>
                            </div>

                                        
                        </div>
            
                        <div class="form-btns">
                            <div class="close-btn" style="display:none">
                                <button id="closeBtn" class="close-btn">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button name="update" class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>


