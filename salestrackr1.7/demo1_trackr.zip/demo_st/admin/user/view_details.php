<?php
// admin/user/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session


if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT 
               user.id as id,
               user.name as name,
               user.code as code,
               user.passcode as passcode,
               role.name as role_name,
               user.phone as phone,
               user.email as email,
               warehouse.name as wh,
               user.note as note
            FROM user
            JOIN role ON user.role_id = role.id
            JOIN warehouse ON user.warehouse_id = warehouse.id
            WHERE user.id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){     
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $passcode = $row['passcode'];
            $email = $row['email'];
            $wh = $row['wh'];
            $role = $row['role_name'];
            $phone = $row['phone'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Details | Users';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>

            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Warehouse</th> 
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT
                                user.id as id,
                                user.code as code, 
                                user.name as name, 
                                phone,
                                passcode,
                                warehouse.name as wh,
                                role.name as role_name, 
                                email 
                                FROM user
                                INNER JOIN role ON user.role_id = role.id
                                INNER JOIN warehouse ON user.warehouse_id = warehouse.id
                                ORDER BY user.id DESC";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action"><?php echo $row['role_name'];?></td>
                                <td class="td-action"><?php echo $row['wh'];?></td>
                                
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>

    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>User Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure><?php echo $name ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Phone:</span>
                                <figure><?php echo $phone ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Email:</span>
                                <figure><?php echo $email ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Password:</span>
                                <figure><?php echo $passcode ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Role:</span>
                                <figure><?php echo $role ?></figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note ?></figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button class="close-btn closeView">CLOSE</button>
                            </a>
                            
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>

