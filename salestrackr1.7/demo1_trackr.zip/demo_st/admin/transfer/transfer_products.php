<?php
include('../../config.php');

// Get the data from the AJAX request
$productIds = isset($_POST['productid']) ? $_POST['productid'] : null;
$quantities = isset($_POST['quantity']) ? $_POST['quantity'] : null;
$fromWarehouse = isset($_POST['from_warehouse']) ? $_POST['from_warehouse'] : null;
$toWarehouse = isset($_POST['to_warehouse']) ? $_POST['to_warehouse'] : null;

if ($productIds && $quantities && $fromWarehouse && $toWarehouse) {
    // Start a transaction
    $conn->begin_transaction();

    try {
        // Loop through each product and its quantity
        foreach ($productIds as $key => $productId) {
            // Get the quantity to transfer
            $quantityToTransfer = $quantities[$key];

            // Check if there is enough stock in the "from" warehouse
            $fromStockQuery = "SELECT quantity FROM stock WHERE product_id = $productId AND warehouse_id = $fromWarehouse";
            $fromStockResult = $conn->query($fromStockQuery);

            if ($fromStockResult && $fromStockResult->num_rows > 0) {
                $fromStockRow = $fromStockResult->fetch_assoc();
                $fromStockQuantity = $fromStockRow['quantity'];

                if ($fromStockQuantity >= $quantityToTransfer) {
                    // Subtract the quantity from the "from" warehouse
                    $subtractQuery = "UPDATE stock SET quantity = quantity - $quantityToTransfer WHERE product_id = $productId AND warehouse_id = $fromWarehouse";
                    $conn->query($subtractQuery);

                    // Add the quantity to the "to" warehouse
                    $addQuery = "INSERT INTO stock (warehouse_id, product_id, quantity) VALUES ($toWarehouse, $productId, $quantityToTransfer)
                                 ON DUPLICATE KEY UPDATE quantity = quantity + $quantityToTransfer";
                    $conn->query($addQuery);
                } else {
                    throw new Exception("Insufficient stock for product ID $productId in warehouse $fromWarehouse");
                }
            } else {
                throw new Exception("Stock not found for product ID $productId in warehouse $fromWarehouse");
            }
        }

        // Commit the transaction
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $conn->rollback();
        echo json_encode(['error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Missing required parameters']);
}

// Close the database connection
$conn->close();


