<?php
// admin/customer/edit.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "UPDATE `customer` SET `code` = '$code', `name` = '$name', `note` = '$note', `phone` = '$phone', `email` = '$email', `address` = '$address' WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT 
               *
            FROM customer
            WHERE id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $id = $row['id'];
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $phone = $row['phone'];
            $email = $row['email'];
            $address = $row['address'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Edit Customer Details';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Contacts</th>
                        <th>Credit</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                    include('../../config.php');

                    // SQL query to get the total sales for each customer
                    $sqlTotalSales = "SELECT customer_id, SUM(actual_amount), SUM(payments.amount),
                                          (SUM(actual_amount) - SUM(payments.amount)) AS total_sales
                                      FROM unique_activity
                                      JOIN sale ON unique_activity.code = sale.code
                                      JOIN transactions ON unique_activity.trans_id = transactions.id
                                      JOIN payments ON unique_activity.code = payments.code
                                      WHERE transactions.name = 'Sale'
                                      GROUP BY customer_id";

                    // SQL query to get the total returns for each customer
                    $sqlTotalReturns = "SELECT customer_id, SUM(actual_amount), SUM(payments.amount),
                                            (SUM(actual_amount) - SUM(payments.amount)) AS total_returns
                                        FROM unique_activity
                                        JOIN sale_return ON unique_activity.code = sale_return.code
                                        JOIN transactions ON unique_activity.trans_id = transactions.id
                                        JOIN payments ON unique_activity.code = payments.code
                                        WHERE transactions.name = 'Sale_return'
                                        GROUP BY customer_id";

                    // Execute the SQL queries
                    $resultTotalSales = $conn->query($sqlTotalSales);
                    $resultTotalReturns = $conn->query($sqlTotalReturns);

                    // Combine the results into an associative array for easy access
                    $totalSales = array();
                    while ($row = $resultTotalSales->fetch_assoc()) {
                        $totalSales[$row['customer_id']] = $row['total_sales'];
                    }

                    $totalReturns = array();
                    while ($row = $resultTotalReturns->fetch_assoc()) {
                        $totalReturns[$row['customer_id']] = $row['total_returns'];
                    }

                    // Output the table rows with total credit
                    $sqlCustomers = "SELECT id, code, name, phone, email, customer.note as cus_note FROM customer ORDER BY customer.id DESC";
                    $resultCustomers = $conn->query($sqlCustomers);

                    if ($resultCustomers->num_rows > 0) {
                        while ($row = $resultCustomers->fetch_assoc()) {
                            // Calculate total credit for each customer
                            $customer_id = $row['id'];
                            $total_credit = isset($totalSales[$customer_id]) ? $totalSales[$customer_id] - (isset($totalReturns[$customer_id]) ? $totalReturns[$customer_id] : 0) : 0;
                            ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action">
                                    <p><?php echo $row['phone'];?></p>
                                    <p><?php echo $row['email'];?></p>
                                </td>
                                <td class="td-amount"><?php echo number_format($total_credit); ?></td>
                                <td class="td-action"><?php echo $row['cus_note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                            <?php
                        }
                    }
                    ?>

                    

                </tbody>

            </table>
        </div>
    </section>


                <!--Edit details-->
                <div class="edit-pop">
                    <div class="popup-container editContainer" style="display:block">
                        <div class="popup view-pop" style="display:block">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Edit Customer Details</h2>
                                    </div>
                                    <input type="hidden" name="view_id" value="<?php echo $id;?>">
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" value="<?php echo $name;?>">
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code" value="<?php echo $code;?>">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="number" name="phone" value="<?php echo $phone;?>">
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="number" name="email" value="<?php echo $email;?>">
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Address:</label><br>
                                            <input type="number" name="address" value="<?php echo $address;?>">
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note"><?php echo $note;?></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn" style="display:none">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="update" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>



    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>

