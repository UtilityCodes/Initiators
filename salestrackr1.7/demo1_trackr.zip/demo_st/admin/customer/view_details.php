<?php
// admin/customer/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session


if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT 
               *
            FROM customer
            WHERE id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){     
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $phone = $row['phone'];
            $email = $row['email'];
            $address = $row['address'];
        }

        ?>

            <!DOCTYPE html>
            <html lang="en">
<?php
       $title = 'Details | Customer';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                </div>
                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Contacts</th>
                        <th>Credit</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                    include('../../config.php');

                    // SQL query to get the total sales for each customer
                    $sqlTotalSales = "SELECT customer_id, SUM(actual_amount), SUM(payments.amount),
                                          (SUM(actual_amount) - SUM(payments.amount)) AS total_sales
                                      FROM unique_activity
                                      JOIN sale ON unique_activity.code = sale.code
                                      JOIN transactions ON unique_activity.trans_id = transactions.id
                                      JOIN payments ON unique_activity.code = payments.code
                                      WHERE transactions.name = 'Sale'
                                      GROUP BY customer_id";

                    // SQL query to get the total returns for each customer
                    $sqlTotalReturns = "SELECT customer_id, SUM(actual_amount), SUM(payments.amount),
                                            (SUM(actual_amount) - SUM(payments.amount)) AS total_returns
                                        FROM unique_activity
                                        JOIN sale_return ON unique_activity.code = sale_return.code
                                        JOIN transactions ON unique_activity.trans_id = transactions.id
                                        JOIN payments ON unique_activity.code = payments.code
                                        WHERE transactions.name = 'Sale_return'
                                        GROUP BY customer_id";

                    // Execute the SQL queries
                    $resultTotalSales = $conn->query($sqlTotalSales);
                    $resultTotalReturns = $conn->query($sqlTotalReturns);

                    // Combine the results into an associative array for easy access
                    $totalSales = array();
                    while ($row = $resultTotalSales->fetch_assoc()) {
                        $totalSales[$row['customer_id']] = $row['total_sales'];
                    }

                    $totalReturns = array();
                    while ($row = $resultTotalReturns->fetch_assoc()) {
                        $totalReturns[$row['customer_id']] = $row['total_returns'];
                    }

                    // Output the table rows with total credit
                    $sqlCustomers = "SELECT id, code, name, phone, email, customer.note as cus_note FROM customer ORDER BY customer.id DESC";
                    $resultCustomers = $conn->query($sqlCustomers);

                    if ($resultCustomers->num_rows > 0) {
                        while ($row = $resultCustomers->fetch_assoc()) {
                            // Calculate total credit for each customer
                            $customer_id = $row['id'];
                            $total_credit = isset($totalSales[$customer_id]) ? $totalSales[$customer_id] - (isset($totalReturns[$customer_id]) ? $totalReturns[$customer_id] : 0) : 0;
                            ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action">
                                    <p><?php echo $row['phone'];?></p>
                                    <p><?php echo $row['email'];?></p>
                                </td>
                                <td class="td-amount"><?php echo number_format($total_credit); ?></td>
                                <td class="td-action"><?php echo $row['cus_note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                            <?php
                        }
                    }
                    ?>

                    

                </tbody>

            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Customer Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure><?php echo $name ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Phone:</span>
                                <figure><?php echo $phone ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Email:</span>
                                <figure><?php echo $email ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Address:</span>
                                <figure><?php echo $address ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note ?></figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1" style="display: none;">
                                <span class="fixed-title">Debt:</span>
                                <figure>73,000</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button class="close-btn closeView">CLOSE</button>
                            </a>
                            
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
            </html>


    <?php }else{
        header('location: view.php');
    }
}

?>


