<?php
// admin/dashboard/card_row2.php ***
include('../../config.php'); // Include your database connection file

$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

if(isset($_POST['cards2_date_filter'])){
    $defaultStartDate = $_POST['cards2_from_date'];
    $defaultEndDate = $_POST['cards2_to_date'];
}

// FOR PAYMENT IN
$queryPaymentIn = "SELECT DATE(payments.dates) AS payment_date, SUM(payments.amount) AS total_payment_in
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    JOIN trans_type ON transactions.trans_type_id = trans_type.id
    WHERE trans_type.name = 'Pay-In'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY payment_date
    ORDER BY payment_date";

$resultPaymentIn = $conn->query($queryPaymentIn);
$paymentInRow = array('total_payment_in' => 0);
if ($resultPaymentIn && $resultPaymentIn->num_rows > 0) {
    $paymentInRow = $resultPaymentIn->fetch_assoc();
}

// FOR PAYMENT OUT
$queryPaymentOut = "SELECT DATE(payments.dates) AS payment_date, SUM(payments.amount) AS total_payment_out
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    JOIN trans_type ON transactions.trans_type_id = trans_type.id
    WHERE trans_type.name = 'Pay-Out'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY payment_date
    ORDER BY payment_date";

$resultPaymentOut = $conn->query($queryPaymentOut);
$paymentOutRow = array('total_payment_out' => 0);
if ($resultPaymentOut && $resultPaymentOut->num_rows > 0) {
    $paymentOutRow = $resultPaymentOut->fetch_assoc();
}

// FOR CASH-IN-HAND
$cashInHand = $paymentInRow['total_payment_in'] - $paymentOutRow['total_payment_out'];

// FOR EXPENSES
$queryExpenses = "SELECT DATE(payments.dates) AS expense_date, SUM(payments.amount) AS total_expenses
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name = 'Expenses'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY expense_date
    ORDER BY expense_date";

$resultExpenses = $conn->query($queryExpenses);
$expenseRow = array('total_expenses' => 0);
if ($resultExpenses && $resultExpenses->num_rows > 0) {
    $expenseRow = $resultExpenses->fetch_assoc();
}

// FOR DRAWINGS
$drawingsSql = "SELECT DATE(payments.dates) AS drawings_date, SUM(payments.amount) AS total_drawings
                FROM payments
                JOIN transactions ON payments.trans_id = transactions.id
                WHERE transactions.name = 'Drawings'
                AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
                GROUP BY drawings_date
                ORDER BY drawings_date";
$resultDrawings = $conn->query($drawingsSql);
$drawingsRow = array('total_drawings' => 0);
if ($resultDrawings && $resultDrawings->num_rows > 0) {
    $drawingsRow = $resultDrawings->fetch_assoc();
}

