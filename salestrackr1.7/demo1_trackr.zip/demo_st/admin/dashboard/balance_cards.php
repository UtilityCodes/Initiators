<?php

// FOR CASH BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Cash
$queryCashIn = "SELECT SUM(payments.amount) AS total_cash_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'CASH' AND trans_type.name = 'Pay-In'";

$resultCashIn = $conn->query($queryCashIn);
$rowCashIn = $resultCashIn->fetch_assoc();
$totalCashIn = $rowCashIn['total_cash_in'];

// Fetch the total Pay-Out amount for Cash
$queryCashOut = "SELECT SUM(payments.amount) AS total_cash_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'CASH' AND trans_type.name = 'Pay-Out'";

$resultCashOut = $conn->query($queryCashOut);
$rowCashOut = $resultCashOut->fetch_assoc();
$totalCashOut = $rowCashOut['total_cash_out'];

// Calculate the Cash balance
$cashBalance = $totalCashIn - $totalCashOut;


// FOR BANK BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Bank
$queryBankIn = "SELECT SUM(payments.amount) AS total_bank_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'BANK' AND trans_type.name = 'Pay-In'";

$resultBankIn = $conn->query($queryBankIn);
$rowBankIn = $resultBankIn->fetch_assoc();
$totalBankIn = $rowBankIn['total_bank_in'];

// Fetch the total Pay-Out amount for Bank
$queryBankOut = "SELECT SUM(payments.amount) AS total_bank_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'BANK' AND trans_type.name = 'Pay-Out'";

$resultBankOut = $conn->query($queryBankOut);
$rowBankOut = $resultBankOut->fetch_assoc();
$totalBankOut = $rowBankOut['total_bank_out'];

// Calculate the Bank balance
$bankBalance = $totalBankIn - $totalBankOut;


// FOR MOBILE BALANCE ALL TIME ******
// Fetch the total Pay-In amount for Mobile
$queryMobileIn = "SELECT SUM(payments.amount) AS total_mobile_in
                FROM payments
                JOIN account ON payments.account_id = account.id
                JOIN transactions ON payments.trans_id = transactions.id
                JOIN trans_type ON transactions.trans_type_id = trans_type.id
                WHERE account.name = 'MOBILE' AND trans_type.name = 'Pay-In'";

$resultMobileIn = $conn->query($queryMobileIn);
$rowMobileIn = $resultMobileIn->fetch_assoc();
$totalMobileIn = $rowMobileIn['total_mobile_in'];

// Fetch the total Pay-Out amount for Mobile
$queryMobileOut = "SELECT SUM(payments.amount) AS total_mobile_out
                 FROM payments
                 JOIN account ON payments.account_id = account.id
                 JOIN transactions ON payments.trans_id = transactions.id
                 JOIN trans_type ON transactions.trans_type_id = trans_type.id
                 WHERE account.name = 'MOBILE' AND trans_type.name = 'Pay-Out'";

$resultMobileOut = $conn->query($queryMobileOut);
$rowMobileOut = $resultMobileOut->fetch_assoc();
$totalMobileOut = $rowMobileOut['total_mobile_out'];

// Calculate the Mobile balance
$mobileBalance = $totalMobileIn - $totalMobileOut;
//all time balance end