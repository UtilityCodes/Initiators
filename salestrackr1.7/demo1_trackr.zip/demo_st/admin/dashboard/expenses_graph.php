<?php
// admin/dashboard/expenses_graph.php
include('../../config.php'); // Include your database connection file

$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

$queryExpenses = "SELECT DATE(payments.dates) AS expense_date, SUM(payments.amount) AS total_expenses
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name = 'Expenses'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY expense_date
    ORDER BY expense_date";

$result = $conn->query($queryExpenses);

$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = array(
        'date' => $row['expense_date'],
        'total_expenses' => $row['total_expenses']
    );
}

header('Content-Type: application/json');
echo json_encode($data);
$conn->close();

