<?php
// card_row1.php
// include("../../connfig.php");
// ********** 

// Default date range: One week
$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

if (isset($_POST['filter_card1_date'])) {
    $defaultStartDate = $_POST['start_card1_date'];
    $defaultEndDate = $_POST['end_card1_date'];


}

    // FOR REVENUE
    $queryRevenue = "SELECT SUM(payments.amount) AS total_revenue
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name IN ('Sale', 'Service_sale')
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultRevenue = $conn->query($queryRevenue);
    $rowRevenue = $resultRevenue->fetch_assoc();
    $totalRevenue = $rowRevenue['total_revenue'];

    // FOR SALES RETURN
    $querySR = "SELECT SUM(payments.amount) AS total_sr
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name = 'Sale_return'
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultSR = $conn->query($querySR);
    $rowSR = $resultSR->fetch_assoc();
    $totalSR = $rowSR['total_sr'];

    // FOR TOTAL DEBIT
    $queryUniqueActivity = "SELECT SUM(actual_amount) AS total_debit_unique_activity
          FROM unique_activity
          JOIN transactions ON unique_activity.trans_id = transactions.id
          WHERE transactions.name IN ('Purchase', 'Sale_return')
          AND unique_activity.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";
          
    $resultUniqueActivity = $conn->query($queryUniqueActivity);
    $rowUniqueActivity = $resultUniqueActivity->fetch_assoc();
    $totalDebitUniqueActivity = $rowUniqueActivity['total_debit_unique_activity'];

    $queryPayments = "SELECT SUM(payments.amount) AS total_debit_payments
     FROM payments
     JOIN transactions ON payments.trans_id = transactions.id
     WHERE transactions.name IN ('Purchase', 'Sale_return')
     AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultPayments = $conn->query($queryPayments);
    $rowPayments = $resultPayments->fetch_assoc();
    $totalDebitPayments = $rowPayments['total_debit_payments'];

    $totalDebit = $totalDebitUniqueActivity - $totalDebitPayments;

    // FOR PURCHASES
    $queryPurchases = "SELECT SUM(payments.amount) AS total_purchases
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name IN ('Purchase')
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultPurchases = $conn->query($queryPurchases);
    $rowPurchases = $resultPurchases->fetch_assoc();
    $totalPurchases = $rowPurchases['total_purchases'];

    // FOR PURCHASE RETURN
    $queryPR = "SELECT SUM(payments.amount) AS total_pr
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name IN ('Purchase_return')
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultPR = $conn->query($queryPR);
    $rowPR = $resultPR->fetch_assoc();
    $totalPR = $rowPR['total_pr'];

    // FOR TOTAL CREDIT
    $queryUniqueActivity2 = "SELECT SUM(actual_amount) AS total_credit_unique_activity
          FROM unique_activity
          JOIN transactions ON unique_activity.trans_id = transactions.id
          WHERE transactions.name IN ('Sale', 'Service_sale', 'Purchase_return')
          AND unique_activity.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";
          
    $resultUniqueActivity2 = $conn->query($queryUniqueActivity2);
    $rowUniqueActivity2 = $resultUniqueActivity2->fetch_assoc();
    $totalCreditUniqueActivity = $rowUniqueActivity2['total_credit_unique_activity'];

    $queryPayments2 = "SELECT SUM(payments.amount) AS total_credit_payments
     FROM payments
     JOIN transactions ON payments.trans_id = transactions.id
     WHERE transactions.name IN ('Sale', 'Service_sale', 'Purchase_return')
     AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'";

    $resultPayments2 = $conn->query($queryPayments2);
    $rowPayments2 = $resultPayments2->fetch_assoc();
    $totalCreditPayments = $rowPayments2['total_credit_payments'];

    $totalCredit = $totalCreditUniqueActivity - $totalCreditPayments;
