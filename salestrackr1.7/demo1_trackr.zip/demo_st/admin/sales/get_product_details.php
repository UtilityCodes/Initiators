<?php
// get_product_details.php
include '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['product']) && isset($_GET['warehouse'])) {
    $productName = $_GET['product'];
    $warehouseId = $_GET['warehouse'];

    // Fetch product details based on the provided name or barcode and warehouse
    $productDetailsQuery = "SELECT 
                            product.id as id,
                            product.name as name,
                            product.code as code,
                            product.selling_price as selling_price,
                            unit.name as unit_name,
                            stock.quantity as quantity
                        FROM product
                        INNER JOIN unit ON product.unit_id = unit.id
                        INNER JOIN stock ON product.id = stock.product_id
                        WHERE (product.name = '$productName' OR product.code = '$productName') 
                        AND stock.warehouse_id = '$warehouseId'";
    $result = $conn->query($productDetailsQuery);

    if ($result && $result->num_rows > 0) {
        $productDetails = $result->fetch_assoc();

        // Return product details as JSON
        header('Content-Type: application/json');
        echo json_encode($productDetails);
    } else {
        // Product not found
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
    }
} else {
    // Invalid request
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();






