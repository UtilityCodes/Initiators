<?php
// admin/sales/get_products_by_warehouse.php
include('../../config.php');

// Get the selected warehouse ID from the AJAX request
$selectedWarehouse = isset($_GET['warehouse']) ? $_GET['warehouse'] : null;

if ($selectedWarehouse !== null) {
    // Fetch product data for the datalist based on the selected warehouse
    $productData = $conn->query("SELECT 
                                    product.id as id, 
                                    product.code as code,
                                    product.name as name
                                    FROM product
                                    INNER JOIN stock ON product.id = stock.product_id
                                    WHERE stock.warehouse_id = '$selectedWarehouse'
                                    AND stock.quantity > 0");

    if (!$productData) {
        die("Query failed: " . $conn->error);
    }

    // Fetchh all products and send them as JSON response
    $products = $productData->fetch_all(MYSQLI_ASSOC);
    echo json_encode($products);
} else {
    // If no warehouse is selected, return an empty array
    echo json_encode([]);
}

// Close the database connection
$conn->close();


