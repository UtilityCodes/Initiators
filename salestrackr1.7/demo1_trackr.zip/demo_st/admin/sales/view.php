<?php
// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session
?>


<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Sale List';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <a href="add.php"> <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button></a>                 

                </div>
                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Code</th>
                        <th>Warehouse</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>User</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                    $sql =  "SELECT 
                                sale.id as id,
                                sale.code as code, 
                                sale.dates as dates,
                                sale.lpo_no as lpo,
                                sale.proforma_no as proforma,
                                sale.dn_no as dn,
                                user.name as user,
                                customer.name as cus,
                                warehouse.name as wh,
                                sale.product_id as product_id,
                                sale.price as price,
                                sale.quantity as quantity,
                                unique_activity.actual_amount as actual_amount,
                                COALESCE(payments.amount_sum, 0) as total_amount,
                                CASE
                                    WHEN (unique_activity.actual_amount) = COALESCE(payments.amount_sum, 0) THEN 'Complete'
                                    WHEN (unique_activity.actual_amount) > COALESCE(payments.amount_sum, 0) THEN 'Incomplete'
                                    WHEN (unique_activity.actual_amount) < COALESCE(payments.amount_sum, 0) THEN 'Not Sure'
                                    WHEN COALESCE(payments.amount_sum, 0) = 0 THEN 'Not paid'
                                    ELSE ''
                                END AS status
                            FROM sale
                            LEFT JOIN (
                                SELECT code, SUM(amount) as amount_sum
                                FROM payments
                                GROUP BY code
                            ) payments ON sale.code = payments.code
                            INNER JOIN unique_activity ON sale.code = unique_activity.code
                            INNER JOIN customer ON sale.customer_id = customer.id
                            INNER JOIN warehouse ON sale.warehouse_id = warehouse.id
                            INNER JOIN user ON sale.user_id = user.id
                            GROUP BY sale.code
                            ORDER BY sale.dates OR sale.id ASC";
       

                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['wh'];?></td>
                                <td class="td-action"><?php echo $row['cus'];?></td>
                                <td class="td-action"><?php echo $row['status'];?></td>
                                <td class="td-action"><?php echo $row['user'];?></td>
                                <!-- <td class="td-action">
                                     <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="edit-btn editBtn" data-id="">Edit</a>
                                            <a href="#" class="addPay">Add Payment</a>
                                            <a href="#" class="transDetails" data-id="">Purchase Details</a>
                                            <a href="#" class="productDetails">Product Details</a>
                                            <a href="#" class="payDetails">Payment Details</a>
                                            <a href="#" id="printReceipt">Print Receipt</a>
                                            <a href="#" id="quote">Quote</a>
                                            
                                        </span>
                                    </div>
                                </td>  -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>

            </table>
        </div>
    </section>

    <?php
    include('../../assets/components/scripts-1.php');
    ?>
    
</body>
</html>