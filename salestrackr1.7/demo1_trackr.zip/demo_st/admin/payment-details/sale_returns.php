<?php
// admin/payment-details/sale_returns.php
include("../../config.php");

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session
?>
<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Payment Details | Sale Returns';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <a href="add.php"><button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button></a>
                    

                </div>
                <div class="filter--btn" style="display:none;">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Purchase Code</th>
                        <th>Discount</th>
                        <th>Amount</th>
                        <th>Paid</th>
                        <th>Remaining</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                    $sql =  "SELECT 
                                unique_activity.id as id,
                                unique_activity.code as code,
                                payments.dates as dates,
                                unique_activity.discount as discount,
                                unique_activity.actual_amount as actual_amount,
                                COALESCE(payments.amount_sum, 0) as total_amount,
                                (unique_activity.actual_amount) - (COALESCE(payments.amount_sum, 0)) as remaining
                            FROM unique_activity
                            LEFT JOIN (
                                SELECT code, payments.dates, SUM(amount) as amount_sum
                                FROM payments
                                GROUP BY code
                            ) payments ON unique_activity.code = payments.code
                            INNER JOIN sale_return ON unique_activity.code = sale_return.code
                            INNER JOIN warehouse ON sale_return.warehouse_id = warehouse.id
                            GROUP BY unique_activity.code
                            ORDER BY unique_activity.dates OR unique_activity.id ASC";
       

                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-amount"><?php echo number_format($row['discount']);?></td>
                                <td class="td-amount"><?php echo number_format($row['actual_amount']);?></td>
                                <td class="td-amount"><?php echo number_format($row['total_amount']);?></td>
                                <td class="td-amount"><?php echo number_format($row['remaining']);?></td>
                                <!-- <td class="td-action">
                                     <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="edit-btn editBtn" data-id="">Edit</a>
                                            <a href="#" class="addPay">Add Payment</a>
                                            <a href="#" class="transDetails" data-id="">Purchase Details</a>
                                            <a href="#" class="productDetails">Product Details</a>
                                            <a href="#" class="payDetails">Payment Details</a>
                                            <a href="#" id="printReceipt">Print Receipt</a>
                                            <a href="#" id="quote">Quote</a>
                                            
                                        </span>
                                    </div>
                                </td>  -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>

            </table>
        </div>
    </section>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

    <script>
        $(document).ready(function () {
            function showPopup(popupClass) {
                $('.' + popupClass).fadeIn();
                $('.popup').addClass('active');
        }

        function hidePopup(popupClass) {
            $('.' + popupClass).fadeOut();
        }

    // Edit button
    $('.editBtn').on('click', function () {
        showPopup('editContainer');
    });

    $('.closeEditBtn').on('click', function () {
        hidePopup('editContainer');
    });

    // Filter button
    $('#pageFilterBtn').on('click', function () {
        showPopup('filterContainer');
    });

    $('#closeFilter').on('click', function () {
        hidePopup('filterContainer');
    });

    // Add Payment button
    $('.addPay').on('click', function () {
        showPopup('addPayContainer');
    });

    $('.closeAddPay').on('click', function () {
        hidePopup('addPayContainer');
    });

    // Transaction Details button
    $('.transDetails').on('click', function () {
        var purchaseId = $(this).data('id');

        $.ajax({
            url: 'get_purchase_details.php',
            method: 'GET',
            data: { purchaseId: purchaseId },
            success: function (data) {
                // Update the HTML with fetched details
                // $('.div-1 figure').text(data.date);
                // $('.div-2 figure').text(data.code);
                // $('.div-3 figure').text(data.supplierName);
                // $('.div-4 figure').text(data.supplierPhone);
                // $('.div-5 figure').text(data.supplierEmail);
                // $('.div-6 figure').text(data.warehouseName);
                // $('.div-7 figure').text(data.userName);
                // Add similar lines for other details
                // Update the HTML with fetched details
                updateDetail('.div-1 figure', data.purchase_date);
                updateDetail('.div-2 figure', data.purchase_code);
                updateDetail('.div-3 figure', data.supplier_name);
                updateDetail('.div-4 figure', data.supplier_phone);
                updateDetail('.div-5 figure', data.supplier_email);
                updateDetail('.div-6 figure', data.warehouse_name);
                updateDetail('.div-7 figure', data.user_name);


                // Show the popup
                $('.transDetailsContainer').fadeIn();
                $('.popup').addClass('active');
            },
            error: function () {
                console.log('Error fetching purchase details');
            }
        });
    });

    // Function to update detail in the HTML
    function updateDetail(selector, value) {
        $(selector).text(value);
    }

    $('.closeTransDetails').on('click', function () {
        hidePopup('transDetailsContainer');
    });

    // Product Details button
    $('.productDetails').on('click', function () {
        showPopup('productDetailsContainer');
    });

    $('.closeProductDetails').on('click', function () {
        hidePopup('productDetailsContainer');
    });

    // Payment Details button
    $('.payDetails').on('click', function () {
        showPopup('payDetailsContainer');
    });

    $('.closePayDetails').on('click', function () {
        hidePopup('payDetailsContainer');
    });
});

    </script>

    
</body>
</html>