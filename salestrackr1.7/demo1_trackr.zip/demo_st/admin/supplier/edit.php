<?php
// admin/customer/edit.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $sql = "UPDATE `supplier` SET `code` = '$code', `name` = '$name', `note` = '$note', `phone` = '$phone', `email` = '$email', `address` = '$address' WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT 
               *
            FROM supplier
            WHERE id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $id = $row['id'];
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $phone = $row['phone'];
            $email = $row['email'];
            $address = $row['address'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Edit | Suppliers';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>
                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Contacts</th>
                        <th>Debt</th>
                        <!-- <th>Note</th> -->
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                    include('../../config.php');

                    // SQL query to get the total purchases for each supplier
                    $sqlTotalPurchases = "SELECT supplier_id, SUM(actual_amount), SUM(payments.amount),
                                            (SUM(actual_amount) - SUM(payments.amount)) AS total_purchases
                                      FROM unique_activity
                                      JOIN purchase ON unique_activity.code = purchase.code
                                      JOIN transactions ON unique_activity.trans_id = transactions.id
                                      JOIN payments ON unique_activity.code = payments.code
                                      WHERE transactions.name = 'Purchase'
                                      GROUP BY supplier_id";

                    // SQL query to get the total returns for each supplier
                    $sqlTotalReturns = "SELECT supplier_id, SUM(actual_amount), SUM(payments.amount),
                                            (SUM(actual_amount) - SUM(payments.amount)) AS total_returns
                                        FROM unique_activity
                                        JOIN purchase_return ON unique_activity.code = purchase_return.code
                                        JOIN transactions ON unique_activity.trans_id = transactions.id
                                        JOIN payments ON unique_activity.code = payments.code
                                        WHERE transactions.name = 'Purchase_return'
                                        GROUP BY supplier_id";

                    // Execute the SQL queries
                    $resultTotalPurchases = $conn->query($sqlTotalPurchases);
                    $resultTotalReturns = $conn->query($sqlTotalReturns);

                    // Combine the results into an associative array for easy access
                    $totalPurchases = array();
                    while ($row = $resultTotalPurchases->fetch_assoc()) {
                        $totalPurchases[$row['supplier_id']] = $row['total_purchases'];
                    }

                    $totalReturns = array();
                    while ($row = $resultTotalReturns->fetch_assoc()) {
                        $totalReturns[$row['supplier_id']] = $row['total_returns'];
                    }

                    // Output the table rows with total debit
                    $sqlSuppliers = "SELECT id, code, name, phone, email, supplier.note as sup_note FROM supplier ORDER BY supplier.id DESC";
                    $resultSuppliers = $conn->query($sqlSuppliers);

                    if ($resultSuppliers->num_rows > 0) {
                        while ($row = $resultSuppliers->fetch_assoc()) {
                            // Calculate total credit for each supplier
                            $supplier_id = $row['id'];
                            $total_debit = isset($totalPurchases[$supplier_id]) ? $totalPurchases[$supplier_id] - (isset($totalReturns[$supplier_id]) ? $totalReturns[$supplier_id] : 0) : 0;
                            ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action">
                                    <p><?php echo $row['phone'];?></p>
                                    <p><?php echo $row['email'];?></p>
                                </td>
                                <td class="td-amount"><?php echo number_format($total_debit); ?></td>
                                <!-- <td class="td-action"><?php echo $row['sup_note'];?></td> -->
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="view_details.php?id=<?php echo $row['id'];?>" class="view-btn viewBtn">View</a>
                                            <a href="edit.php?id=<?php echo $row['id'];?>" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                            <?php
                        }
                    }
                    ?>

                    

                </tbody>

            </table>
        </div>
    </section>


                    <!--Edit details-->
                    <div class="popup-container editContainer" style="display:block">
                        <div class="popup view-pop" style="display:block">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Edit Supplier Details</h2>
                                    </div>
                                    <input type="hidden" name="view_id" value="<?php echo $id;?>">
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" value="<?php echo $name;?>">
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code" value="<?php echo $code;?>">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="number" name="phone" value="<?php echo $phone;?>">
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="number" name="email" value="<?php echo $email;?>">
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Address:</label><br>
                                            <input type="number" name="address" value="<?php echo $address;?>">
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note"><?php echo $note;?></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn" style="display:block">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="update" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>





