<?php
// admin/expenses/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session


if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT 
               expense.id as id,
               dates,
               expense.code as code,
               type.name as type,
               amount,
               account.name as account,
               warehouse.name as wh,
               expense.note as note,
               user.name as user
            FROM expense
            JOIN type ON expense.type_id = type.id
            JOIN warehouse ON expense.warehouse_id = warehouse.id
            JOIN account ON expense.account_id = account.id
            JOIN user ON expense.user_id = user.id
            WHERE expense.id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){     
            $date = $row["dates"];
            $code = $row['code'];
            $type = $row['type'];
            $amount = number_format($row['amount']);
            $account = $row['account'];
            $wh = $row['wh'];
            $note = $row['note'];
            $user = $row['user'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Details | Expenses';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>
                <div class="filter--btn" style="display:none">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Code</th>                      
                        <th>Expense Type</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT 
                            expense.id as id,
                            expense.code as code, 
                            dates, 
                            account.name as ac_name,
                            type.name as type_name, 
                            amount 
                            FROM expense
                            INNER JOIN type ON expense.type_id = type.id
                            INNER JOIN account ON expense.account_id = account.id
                            ORDER BY dates ASC";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['type_name'];?></td>
                                <td class="td-action"><?php echo $row['ac_name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['amount']);?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                            <!-- <a href="#" class="delete-btn deleteBtn">Delete</a> -->
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Expense Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date:</span>
                                <figure><?php echo $date ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Expense-type:</span>
                                <figure><?php echo $type ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount:</span>
                                <figure><?php echo $amount ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Account:</span>
                                <figure><?php echo $account ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Warehouse:</span>
                                <figure><?php echo $wh ?></figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">User: </span>
                                <figure><?php echo $user ?></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button class="close-btn closeView">CLOSE</button>
                            </a>
                            
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>



