<?php
// admin/payment/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

// Retrieve transaction data for dropdown
$transaction_query = "SELECT id, name FROM transactions";
$transaction_result = $conn->query($transaction_query);
$transactions = $transaction_result->fetch_all(MYSQLI_ASSOC);


if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "SELECT 
               payments.id as pay_id,
               payments.code as code,
               payments.amount as amount,
               account.name as account,
               transactions.name as trans,
               warehouse.name as wh,
               user.name as user,
               payments.pay_code as pay_code,
               payments.dates as dates,
               payments.note as note
            FROM payments
            JOIN account ON payments.account_id = account.id
            JOIN warehouse ON payments.warehouse_id = warehouse.id
            JOIN transactions ON payments.trans_id = transactions.id
            JOIN user ON payments.user_id = user.id
            WHERE payments.id = '$id' ";
    
    
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){     
            $code = $row['code'];
            $amount = number_format($row['amount']);
            $account = $row['account'];
            $trans = $row['trans'];
            $wh = $row['wh'];
            $user = $row['user'];
            $payCode = $row['pay_code'];
            $dates = $row['dates'];
            $note = $row['note'];
        }

        ?>

<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Payments Details';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Payment Code</th>
                        <th>Transaction Code</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql =  "SELECT
                                payments.id as id, 
                                payments.pay_code as code, 
                                payments.dates as dates, 
                                payments.code as trans_code,
                                payments.note as note,
                                transactions.name as trans_name,
                                account.name AS account_name, 
                                payments.amount as amount
                            FROM payments
                            INNER JOIN account ON payments.account_id = account.id
                            INNER JOIN transactions ON payments.trans_id = transactions.id
                            ORDER BY payments.dates AND payments.id desc ";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['trans_code'];?></td>
                                <td class="td-action"><?php echo $row['account_name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['amount']);?></td>
                                <td class="td-action"><?php echo $row['note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="view_details.php?id=<?php echo $row['id'];?>" class="view-btn viewBtn">View</a>
                                            <a href="delete.php?id=<?php echo $row['id'];?>" class="delete-btn deleteBtn">Delete</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Payment Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date:</span>
                                <figure><?php echo $dates ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $payCode ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Transaction-type:</span>
                                <figure><?php echo $trans ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Transaction-Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">

                            <div class="div-1">
                                <span class="fixed-title">Account:</span>
                                <figure><?php echo $account ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Warehouse:</span>
                                <figure><?php echo $wh ?></figure>
                            </div>

                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Amount:</span>
                                <figure><?php echo $amount ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note ?></figure>
                            </div>
                        </div>

                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button class="close-btn closeView">CLOSE</button>
                            </a>
                            
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
</html>


    <?php }else{
        header('location: view.php');
    }
}

?>



