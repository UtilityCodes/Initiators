<?php
// admin/payment/delete.php
include "../../config.php";

if(isset($_GET['id'])){
    $viewId = $_GET['id'];
    
    $sql = "DELETE FROM `payments` WHERE `id` = '$viewId'";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}