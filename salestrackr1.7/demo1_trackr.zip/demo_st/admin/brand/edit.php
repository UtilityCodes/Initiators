<?php
// admin/brand/edit.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

if (isset($_POST['update'])){
    $viewId = $_POST['view_id'];
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    $sql = "UPDATE `brand` SET `code` = '$code', `name` = '$name', `note` = '$note' WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result == TRUE){
        header('location: view.php');
    }else{
        echo 'Error:' . $sql . "<br>" . $conn->error;
    }
}

if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT * FROM `brand` WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $id = $row['id'];


        }

        ?>

        <!DOCTYPE html>
        <html lang="en">
            <?php
               $title = 'Edit Brand Details';
               include('../../assets/components/head.php'); 
            ?>
        <body>
    
        
            <?php
            include('../../assets/components/nav.php');
            ?>
            
        
   
            <section class="content">
                <?php
                include('../../assets/components/header.php');
                ?>

                <div class="computation-btns">
                    <div class="manual-computations">
                        <div class="add-btn">
                            <button id="brandPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                        </div>
                    </div>
                    <?php
                    include('../../assets/components/auto-comp.php');
                    ?>
                </div>

                <div class="table-list">
                    <table id="view-table" class="display">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Note</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php 
                           include('../../config.php');
                           $sql = "SELECT code, name, note FROM brand";
                           $result = $conn->query($sql);
        
                           if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                                ?>
        
                                    <tr>
                                        <td class="td-action"><?php echo $row['code'];?></td>
                                        <td class="td-action"><?php echo $row['name'];?></td>
                                        <td class="td-action"><?php echo $row['note'];?></td>
                                        <td class="td-action">
                                            <div class="action">
                                                <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                                <span class="action-dropdown">        
                                                    <a href="#" class="view-btn" id="brandViewPop">View</a>
                                                    <a href="#" class="edit-btn" id="brandEditPop">Edit</a>
                                                    <!-- <a href="#" class="filter-btn" id="brandFilterPop">Filter</a> -->
                                                </span>
                                            </div>
                                        </td>
                                    </tr>

                                <?php  }
                            }?>
                    

                        </tbody>
                    </table>
                </div>
            </section>

            <!--for brand view-->
            <div class="edit-pop">
                <div class="popup-container" style="display:block">
                    <div class="popup view-pop" style="display:block">
                        <div class="popup-content">
            
                            <form class="sub-form vertical-form" method="post">
                                <div class="form-input form-heading">
                                    <h2>Edit Brand Details</h2>
                                </div>
                                <input type="hidden" name="view_id" value="<?php echo $id;?>">
                                <div class="form-input text-input">
                                    <label for="">Add Code</label><br>
                                    <input type="text" name="code" value="<?php echo $code;?>">
                                </div>
                                <div class="form-input text-input">
                                    <label for="">Add Name</label><br>
                                    <input type="text" name="name" value="<?php echo $name;?>">
                                </div>
                                <div class="form-input note-input">
                                    <label for="">Description</label><br>
                                    <textarea name="note"><?php echo $note;?></textarea>
                                </div>
                                <div class="form-btns">
                                    <div class="close-btn" style="display:none">
                                        <a href="view.php">
                                            <button class="close-btn">CLOSE</button>
                                        </a>
                                
                                    </div>
                                    <div class="submit-btn">
                                        <button name="update" class="submit-btn">EDIT</button>
                                    </div>
                                </div>
                            </form>
    
                        </div>
                    </div>
                </div>
            </div>

            <?php
            include('../../assets/components/scripts-1.php');
            ?>


        </body>
        </html>


    <?php }else{
        header('location: view.php');
    }
}

?>

