<?php
// admin/brand/view_details.php

include "../../config.php";

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session


if(isset($_GET['id'])){
    $viewId = $_GET['id'];

    $sql = "SELECT *
               
            FROM `brand`
            
            WHERE `id` = '$viewId' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $code = $row['code'];
            $name = $row['name'];
            $note = $row['note'];
            $id = $row['id'];


        }

        ?>

            <!DOCTYPE html>
            <html lang="en">
    <?php
       $title = 'View Brand Details';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button id="brandPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, note FROM brand";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action"><?php echo $row['note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn" id="brandViewPop">View</a>
                                            <a href="#" class="edit-btn" id="brandEditPop">Edit</a>
                                            <!-- <a href="#" class="filter-btn" id="brandFilterPop">Filter</a> -->
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>


    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container" id="brandViewContainer" style="display:block">
            <div class="popup view-pop" style="display:block">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Brand Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure><?php echo $name ?></figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure><?php echo $code ?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1" style="display:none">
                                <span class="fixed-title">No. Of Products:</span>
                                <figure>4</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure><?php echo $note?></figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1" style="display:none">
                                <span class="fixed-title">No. Of Categories:</span>
                                <figure>4</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <a href="view.php">
                                <button id="closeBrandEdit" class="close-btn">CLOSE</button>
                            </a>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>

</body>
            </html>


    <?php }else{
        header('location: view.php');
    }
}

?>



