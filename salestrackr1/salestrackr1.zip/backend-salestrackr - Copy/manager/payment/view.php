<?php
// manager/payment/view.php
// Include the database connection file
include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

function generatePayCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $payCode = 'pay-' . '-' . $timestamp;

    return $payCode;
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $transCode = $_POST['trans_code'];
    $dates = $_POST['date'];
    $amount = $_POST['amount'];
    $user_id = $_SESSION['user_id'];
    $account_id = $_POST['account_id'];
    $warehouse_id = $_POST['warehouse_id'];
    $note = $_POST['note'];

    $payCode = generatePayCode();

    if($dates == null || $note == null || $warehouse_id == null){
        $date = date('Y-m-d H:i:s');
        $note = 'No Note';
        $warehouseId = $_SESSION['warehouse_id'];
    }
    

    // Insert data into the 'payment' table
        $paymentSql = "INSERT INTO payments (code, pay_code, dates, amount, account_id, warehouse_id, user_id, note, trans_id) 
                   VALUES ('$transCode', '$payCode', '$dates', '$amount', '$account_id', '$warehouse_id', '$user_id', '$note', '7')";
        $conn->query($paymentSql);
    
    if ($conn->query($paymentSql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


// Retrieve account data for dropdown
$account_query = "SELECT id, name FROM account";
$account_result = $conn->query($account_query);
$accounts = $account_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);



// Close the database connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Payments';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Payment</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Date:</label><br>
                                            <input type="date" name="date" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for=""> Transaction Code:</label><br>
                                            <input type="text" name="trans_code" required>
                                        </div>
            
                                    </div>
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Account:</label><br>
                                            <input list="accounts" id="accountId" name="account_id" required>
                                            <datalist id="accounts">
                                                <?php
                                                    foreach ($accounts as $account) {
                                                        echo "<option value='{$account['id']}'>{$account['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <input list="warehouses" id="warehouseId" name="warehouse_id" required>
                                            <datalist id="warehouses">
                                                <?php
                                                    foreach ($warehouses as $warehouse) {
                                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>


                                    </div>


                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Amount:</label><br>
                                            <input type="number" name="amount" required>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note" id=""></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBtn" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>

                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Payment Code</th>
                        <th>Transaction Code</th>
                        <th>Account</th>
                        <th>Amount</th>
                        <th>Note</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql =  "SELECT 
                                payments.pay_code as code, 
                                payments.dates as dates, 
                                payments.code as trans_code,
                                payments.note as note,
                                transactions.name as trans_name,
                                account.name AS account_name, 
                                payments.amount as amount
                            FROM payments
                            INNER JOIN account ON payments.account_id = account.id
                            INNER JOIN transactions ON payments.trans_id = transactions.id
                            ORDER BY payments.dates AND payments.id desc ";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['trans_code'];?></td>
                                <td class="td-action"><?php echo $row['account_name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['amount']);?></td>
                                <td class="td-action"><?php echo $row['note'];?></td>
                                <!-- <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                        </span>
                                    </div>
                                </td> -->
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Payment Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date:</span>
                                <figure>12-03-2024</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Transaction-type:</span>
                                <figure>Sales</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Transaction-Code:</span>
                                <figure>S-221</figure>
                            </div>
                        </div>
                        <div class="view-div">

                            <div class="div-1">
                                <span class="fixed-title">Account:</span>
                                <figure>Bank</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Warehouse:</span>
                                <figure>WH-3</figure>
                            </div>

                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Amount:</span>
                                <figure>500,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>

                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
      
    

</body>
</html>