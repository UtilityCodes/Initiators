<?php
// manager/category/view.php
// Include the database connection file
include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

function generateCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $code = 'cate-' . '-' . $timestamp;

    return $code;
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    if($code == null){
        $code = generateCode();      
    }
    if($note == null){
        $note = 'No Note';
    }

    // Insert data into the 'brand' table
    $sql = "INSERT INTO category (code, name, note) VALUES ('$code', '$name', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
   <?php
       $title = 'Categoria';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="categoryPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    <!--Add Brand Popup Form-->
                    <div class="popup-container" id="categoryFormContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form vertical-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Category Details</h2>
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Code</label><br>
                                        <input type="text" name="code">
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Name</label><br>
                                        <input type="text" name="name" required>
                                    </div>
                                    <div class="form-input note-input">
                                        <label for="">Description</label><br>
                                        <textarea name="note" id="" cols="42" rows="3"></textarea>
                                    </div>
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closecategoryForm" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Note</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, note FROM category";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['name'];?></td>
                                <td class="td-action"><?php echo $row['note'];?></td>
                                <!-- <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn categoryViewPop" id="categoryViewPop">View</a>
                                            <a href="#" class="edit-btn categoryEditPop" id="categoryEditPop">Edit</a>
                                            <a href="#" class="filter-btn categoryFilterPop" id="categoryFilterPop">Filter</a>
                                        </span>
                                    </div>
                                </td> -->
                            </tr>

                        <?php }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for brand view-->
    <div class="edit-pop">
        <div class="popup-container" id="categoryEditContainer">
            <div class="popup view-pop">
                <div class="popup-content">
    
                    <form action="" class="sub-form vertical-form">
                        <div class="form-input form-heading">
                            <h2>Edit Category Details</h2>
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Code</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Name</label><br>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="" id="" cols="42" rows="3"></textarea>
                        </div>
                        <div class="form-btns">
                            <div class="close-btn">
                                <button id="closecategoryEdit" class="close-btn closecategoryEdit">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container" id="categoryViewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Category Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure>Tooth-Paste</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">No. Of Products:</span>
                                <figure>31</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">No. Of Brands:</span>
                                <figure>4</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button id="closecategoryView" class="close-btn closecategoryView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <!--filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="categoryFilterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter category</h2>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Select Brand</label><br>
                            <input list="categories" class="datalist-input" id="brand" name="brand" autocomplete="off" required>

                            <datalist id="categories">
                                <option value="Brand A">
                                <option value="Brand X">
                                <option value="Brand i">
                            </datalist>
                        </div>
                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closecategoryFilter" class="close-btn closecategoryFilter">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>




    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

            // FOR ADD-BRAND BUTTON ****
            $('#categoryPopBtn').on('click', function () {
                $('#categoryFormContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closecategoryForm').on('click', function () {
                $('#categoryFormContainer').fadeOut();
            });

            $('#categoryPopBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR EDIT-category BUTTON ****
            $('.categoryEditPop').on('click', function () {
                $('#categoryEditContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closecategoryEdit').on('click', function () {
                $('#categoryEditContainer').fadeOut();
            });

            $('.categoryEditPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW-category BUTTON ****
            $('.categoryViewPop').on('click', function () {
                $('#categoryViewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closecategoryView').on('click', function () {
                $('#categoryViewContainer').fadeOut();
            });

            $('.categoryViewPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER-category BUTTON ****
            $('.categoryFilterPop').on('click', function () {
                $('#categoryFilterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closecategoryFilter').on('click', function () {
                $('#categoryFilterContainer').fadeOut();
            });

            $('.categoryFilterPop').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>