<?php
// manager/purchases/add.php

include('../../config.php');


// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session

function generatePayCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Generate random three-digit number
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);

    // Concatenate the components to form the receipt code
    $payCode = 'pay-' . $timestamp . '-' . $randomNumber;

    return $payCode;
}


function generateTransCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();

    // Generate random three-digit number
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    
    // Concatenate the components to form the receipt code
    $code = 'pur-' . '-' . $timestamp . '-' . $randomNumber;

    return $code;
}

// Check if the form is submitted for adding purchase
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add']) && isset($_POST['productid']) && isset($_POST['quantity']) && isset($_POST['price'])) {
    $code = isset($_POST['code']) ? $_POST['code'] : null;
    $payCode = generatePayCode();

    $date = isset($_POST['date']) ? $_POST['date'] : null;
    $discount = isset($_POST['discount']) ? $_POST['discount'] : null;
    $actual_amount = isset($_POST['actual_amount']) ? $_POST['actual_amount'] : null;
    $totalAmount = isset($_POST['total']) ? $_POST['total'] : null;

    $supplierId = isset($_POST['supplier_id']) ? $_POST['supplier_id'] : null;
    $warehouseId = isset($_POST['warehouse_id']) ? $_POST['warehouse_id'] : null;

    $note = isset($_POST['note']) ? $_POST['note'] : null;

    $lpoNo = isset($_POST['lpo-no']) ? $_POST['lpo-no'] : null;
    $proformaNo = isset($_POST['proforma-no']) ? $_POST['proforma-no'] : null;
    $dnNo = isset($_POST['dn-no']) ? $_POST['dn-no'] : null;


    $user_id = $_SESSION['user_id'];
    

    if ($code == null || $date == null || $proformaNo == null || $lpoNo == null || $dnNo == null || $warehouseId == null) {
        $code = generateTransCode();
        $date = date('Y-m-d');
        $dnNo = '0';
        $proformaNo = '0';
        $lpoNo = '0';
        // $warehouseId = $_SESSION['warehouse_id'];
    }

    if ($code !== null && $date !== null && $supplierId !== null && $warehouseId !== null
        && $discount !== null
        && $totalAmount !== null && $note !== null && $lpoNo !== null && $proformaNo !== null && $dnNo !== null) {

         // Iterate over the rows in the table
        for ($i = 0; $i < count($_POST['productid']); $i++) {
            $productId = $_POST['productid'][$i];
            $quantity = $_POST['quantity'][$i];
            $price = $_POST['price'][$i];

            // Insert purchase information into the 'purchase' table
            $purchaseSql = "INSERT INTO purchase (code, dates, supplier_id, warehouse_id, product_id, quantity, price, user_id, lpo_no, proforma_no, dn_no) 
                            VALUES ('$code', '$date', '$supplierId', '$warehouseId', '$productId', '$quantity', '$price', '$user_id', '$lpoNo', '$proformaNo', '$dnNo')";
            $purchaseSqlResult = $conn->query($purchaseSql);

            // Update stock information in the 'stock' table
            $stockSqlCheck = "SELECT * FROM stock WHERE product_id = '$productId' AND warehouse_id = '$warehouseId'";
            $stockCheckResult = $conn->query($stockSqlCheck);

            if ($stockCheckResult->num_rows > 0) {
                // If the combination exists, update the quantity
                $existingStock = $stockCheckResult->fetch_assoc();
                $newQuantity = $existingStock['quantity'] + $quantity;

                $stockUpdateSql = "UPDATE stock SET quantity = '$newQuantity' WHERE product_id = '$productId' AND warehouse_id = '$warehouseId'";
                $stockUpdateResult = $conn->query($stockUpdateSql);
            } else {
                // If the combination doesn't exist, insert a new row
                $stockInsertSql = "INSERT INTO stock (product_id, warehouse_id, quantity) 
                                VALUES ('$productId', '$warehouseId', '$quantity')";
                $stockInsertResult = $conn->query($stockInsertSql);
            }

            // Check for success and handle errors as needed
            if (isset($stockUpdateResult) && $stockUpdateResult === FALSE) {
                echo "Error updating stock: " . $conn->error;
            } elseif (isset($stockInsertResult) && $stockInsertResult === FALSE) {
                echo "Error inserting into stock: " . $conn->error;
            }

        }

        if ($purchaseSqlResult === TRUE) {
            // Retrieve the last inserted purchase ID
            $purchaseId = $conn->insert_id;

            // Initialize an array to store payment details
            $paymentDetails = [];

            // Check if Cash input is filled
            if (!empty($_POST['total'])) {
                $cashAmount = $_POST['total'];
                $cashAccountId = 1; // Assuming 1 is the account_id for Cash in your account table

                $paymentDetails[] = [
                    'account_id' => $cashAccountId,
                    'amount' => $cashAmount,
                ];
            }

            // Check if Bank input is filled
            if (!empty($_POST['bankInput'])) {
                $bankAmount = $_POST['bankInput'];
                $bankAccountId = 2; // Assuming 2 is the account_id for Bank in your account table

                $paymentDetails[] = [
                    'account_id' => $bankAccountId,
                    'amount' => $bankAmount,
                ];
            }

            // Check if Mobile input is filled
            if (!empty($_POST['mobileInput'])) {
                $mobileAmount = $_POST['mobileInput'];
                $mobileAccountId = 3; // Assuming 3 is the account_id for Mobile in your account table

                $paymentDetails[] = [
                    'account_id' => $mobileAccountId,
                    'amount' => $mobileAmount,
                ];
            }

            // Check if Other input is filled
            if (!empty($_POST['otherInput'])) {
                $otherAmount = $_POST['otherInput'];
                $otherAccountId = 4; // Assuming 4 is the account_id for Other in your account table

                $paymentDetails[] = [
                    'account_id' => $otherAccountId,
                    'amount' => $otherAmount,
                ];
            }

            // Iterate over payment details and insert rows into the payments table
            foreach ($paymentDetails as $payment) {
                $paymentSql = "INSERT INTO payments (code, pay_code, dates, amount, account_id, warehouse_id, user_id, note, trans_id) 
                               VALUES ('$code', '$payCode', '$date', '{$payment['amount']}', '{$payment['account_id']}', '$warehouseId', '$user_id', '$note', '2')";
                $conn->query($paymentSql);

            }

            $uniqueSql = "INSERT INTO unique_activity (code, dates, discount, actual_amount, trans_id) 
                            VALUES ('$code', '$date', '$discount', '$actual_amount' , '2')";
            $conn->query($uniqueSql);


                    // Purchase added successfully
                    header("location:view.php");
                } else {
                    echo "Error: " . $purchaseSql . "<br>" . $conn->error;
                }
        } else {
                echo "Error: Required fields are not set.";
        }
    }

// Retrieve account data for dropdown
$account_query = "SELECT id, name FROM account";
$account_result = $conn->query($account_query);
$accounts = $account_result->fetch_all(MYSQLI_ASSOC);

// Retrieve supplier data for dropdown
$supplier_query = "SELECT id, name FROM supplier";
$supplier_result = $conn->query($supplier_query);
$suppliers = $supplier_result->fetch_all(MYSQLI_ASSOC);

// Retrieve unit data for dropdown
$unit_query = "SELECT id, name FROM unit";
$unit_result = $conn->query($unit_query);
$units = $unit_result->fetch_all(MYSQLI_ASSOC);

// Retrieve product data for dropdown
$product_query = "SELECT id, name FROM product";
$product_result = $conn->query($product_query);
$products = $product_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);

// Fetch product data for the datalist
$productData = $conn->query("SELECT 
                                product.id as id, 
                                product.name as name, 
                                product.code as code, 
                                product.buying_price as buying_price,
                                unit.name as unit_name 
                                FROM product
                                INNER JOIN unit ON product.unit_id = unit.id");

if (!$productData) {
    die("Query failed: " . $conn->error);
}


// Close the database connection
$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Add Purchases';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav-manager.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="add--section">

            <form class="add-details" method="post" action="">
                <div class="add-option">
                    <div class="options">
                        <div class="code">
                            <label for="">Code:</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="date">
                            <label for="">Date:</label><br>
                            <input type="date" name="date">
                        </div>
                        <div class="people">
                            <label for="supplierId">Supplier:</label><br>
                            <select class="datalist-people" name="supplier_id" id="supplierId">
                                <option value="" selected disabled>Select a supplier</option>
                                <?php
                                    foreach ($suppliers as $supplier) {
                                        echo "<option value='{$supplier['id']}'>{$supplier['name']}</option>";
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="warehouse">
                            <label for="warehouseId">Warehouse:</label><br>
                            <select class="datalist-people" name="warehouse_id" id="warehouseId">
                                <option value="" selected disabled>Select a warehouse</option>
                                <?php
                                    foreach ($warehouses as $warehouse) {
                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                    }
                                ?>
                            </select>
                        </div>

                        <div class="choose-product">
                            <label for="search">Choose Product:</label><br>
                            <input list="products" oninput="handleProductSelection()" id="search" name="search" class="datalist-product">
                            <datalist id="products">
                                <?php
                                $productData->data_seek(0); // Reset the pointer to the beginning
                                while ($row = $productData->fetch_assoc()) {
                                    // echo "<option value=\"{$row['name']} ({$row['code']})\">";
                                    echo "<option value=\"{$row['name']}\">";
                                    echo "<option value=\"{$row['code']}\">";
                                }
                                ?>
                            </datalist>


                        </div>


                    </div>
                </div>

                <div class="add-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Product Name</th>
                                <th>Unit</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody id="productTableBody"></tbody>
                    </table>
                </div>
                <div class="add-footer">
                    <div class="footer-amounts">
                        <div class="discount">
                            <label for="">Discount:</label>
                            <input id="discount" oninput="updateTotal()" name="discount" type="number" value="0.00">
                        </div>
                        <div class="sub-total">
                            <span>Sub-total:</span>
                            <figure id="subtotal">0.00</figure>
                        </div>
                    </div>
                    <div class="footer-btn">
                        <button id="sellBtn">
                            <span class="sell">Buy</span>
                            <div class="total">
                                <span>Total:</span>
                                <figure id="total">0.00</figure>
                                <input type="hidden" name="actual_amount" id="totalInput">
                            </div>
                        </button>
                    </div>
                </div>

                <div class="view-popup">
                    <div class="popup-container" id="purchasePaymentContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="payment-form">
                                    
                                    <div class="payment-card"> 
                                        <div class="pay-card-header">
                                            <h2>Purchase Payment</h2>
                                        </div>
    
                                        <div class="cash-pay-inputs">
                                            <div class="cash-payment">
                                                <div class="cash-input">
                                                    <label for="cashInput">Cash:</label><br>
                                                    <input type="number" id="cashInput" name="total">
                                                </div>
                                                <div class="change-input">
                                                    <label for="change">Change:</label><br>
                                                    <input type="number" name="change" id="change" value="0.00" readonly>
                                                </div>
                                            </div>
                                            <div class="bank-note-mobile">
                                                <div class="mobile-bank">
                                                    <div class="bank-input">
                                                        <label for="bank">Bank:</label><br>
                                                        <input type="number" name="bankInput" id="bankInput">
                                                    </div>
                                                    <div class="mobile-input">
                                                        <label for="mobile">Mobile:</label><br>
                                                        <input type="number" name="mobileInput" id="mobileInput">
                                                    </div>
                                                </div>
                                                <div class="note-input">
                                                    <label for="note">Note:</label><br>
                                                    <textarea name="note" id="note" required></textarea>
                                                </div>
                                            </div>

                                            <div class="other-pay">
                                                <div class="other--input">
                                                    <label for="">Other:</label><br>
                                                    <input type="number" name="otherInput" id="otherInput">
                                                </div>
                                                <div class="other--input">
                                                    <label for=""></label>
                                                    <input type="text" readonly>
                                                </div>
                                            </div>
                                        </div>
    
                                        <div class="credit-pay-inputs">
                                            <div class="credit-pay-header">
                                                <h2>For Credit:</h2>
                                            </div>
                                            <div class="credit-numbers">
                                                <div class="lpo-no">
                                                    <label for="lpoNo">LPO NO.</label><br>
                                                    <input type="number" id="lpoNo" name="lpo-no">
                                                </div>
                                                <div class="proforma-no">
                                                    <label for="proformaNo">Proforma No.</label><br>
                                                    <input type="number" id="proformaNo" name="proforma-no">
                                                </div>
                                                <div class="dn-no">
                                                    <label for="dnNo">DN NO.</label><br>
                                                    <input type="number" name="dn-no" id="dnNo">
                                                </div>
                                            </div>
                                            <!-- <input style="display: none;" required> -->
                                        </div>
                                    </div>
    
                                    <div class="form-btns">
                                        
                                        <div class="close-btn">
                                            <button id="closePay" class="close-btn">CANCEL</button>
                                        </div>
                
                                        <div class="submit-btn">
                                            <button type="submit" name="add" class="submit-btn">PAY</button>
                                        </div>
                
                                    </div>
                            </form>

            

                
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </section>




    <?php
    include('../../assets/components/scripts-1.php');
    ?> 
    
    <script>

        $(document).ready(function () {
            // for sell button ****
            $('#sellBtn').on('click', function () {
                $('#purchasePaymentContainer').fadeIn();
                $('.popup').addClass('active');
            });

            // Close the popup when the close button is clicked
            $('#closePay').on('click', function () {
                $('#purchasePaymentContainer').fadeOut();
            });
        });


        function handleProductSelection() {
            var selectedProduct = document.getElementById('search').value;
            // AJAX request to fetch product details
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {

                        var productDetails = JSON.parse(xhr.responseText);

                        displayProductDetails(productDetails);

                    } else {
                        console.error('Error fetching product details:', xhr.statusText);
                        // Handle the error here, e.g., display an alert to the user
                    }
                }
            };

            xhr.open("GET", "get_product_details.php?product=" + selectedProduct, true);
            xhr.send();
        }

        function displayProductDetails(productDetails) {
            if (productDetails.error) {
                // Handle error, e.g., display an alert
                console.error('Error:', productDetails.error);
            } else {
                var table = document.getElementById('productTableBody');
                var newRow = table.insertRow();
                newRow.innerHTML = `<td>${productDetails.code}</td>
                                    <td class="td-product">${productDetails.name}</td>
                                    <td>${productDetails.unit_name}</td>
                                    <td class="td-amount">${productDetails.buying_price}</td>
                                    <td><input type="number" name="quantity[]" value="1" min="1" oninput="updateAmount(this)" class="quantity-input"></td>
                                    <td class="td-amount">${productDetails.buying_price}</td>
                                    <td><i class="fa fa-times"></i></td>

                                    <input type="hidden" name="productid[]" value="${productDetails.id}">
                                    <input type="hidden" name="price[]" value="${productDetails.buying_price}">`;

                // Update subtotal and total values
                updateTotal();
            }
        }

        function updateAmount(input) {
            var row = input.parentNode.parentNode;
            var price = parseFloat(row.cells[3].textContent);
            var quantity = parseInt(input.value);
            var amount = price * quantity;
            row.cells[5].textContent = amount.toFixed(2);

            // Update subtotal and total values
            updateTotal();
        }

        function updateTotal() {
            var table = document.getElementById('productTableBody');
            var rows = table.querySelectorAll('tr');
            var subtotal = 0;

            rows.forEach(function (row) {
                var amount = parseFloat(row.cells[5].textContent);
                subtotal += amount;
            });

            var discount = parseFloat(document.getElementById('discount').value) || 0;
            var total = subtotal - discount;

            document.getElementById('subtotal').textContent = subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            document.getElementById('total').textContent = total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');

            // Update the value of the hidden input field
            document.getElementById('totalInput').value = total.toFixed(2);
        }
    



    </script>

    
    
    
    

</body>
</html>