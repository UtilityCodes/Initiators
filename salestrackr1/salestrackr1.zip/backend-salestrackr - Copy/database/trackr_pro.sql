-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2024 at 03:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trackr_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `name`) VALUES
(1, 'CASH'),
(2, 'BANK'),
(3, 'MOBILE'),
(4, 'OTHER');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `code`, `name`, `note`) VALUES
(1, '5657', 'skycrawler', 'the best one'),
(5, '343', 'Raytheon', 'delicate'),
(6, '987', 'Aiolyon', 'No Note'),
(7, '3434', 'BRAND 12', 'DFFF'),
(8, '323232', 'BRAND 333', 'DD'),
(9, '67887', 'BRAND 999', 'FFF'),
(10, '24425', 'LG', 'for electronics');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `code`, `name`, `note`) VALUES
(1, '767', 'Beer', 'above 12%'),
(2, '98090898', 'category 55', 'fff'),
(3, '3132', 'category hhh', 'd3d3'),
(4, '444', 'laptop', 'vvv'),
(5, '323', 'washers', 'dfgd'),
(6, '33', 'loop-ropes', 'cfc'),
(7, '34334', 'Television', 'electronics');

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `amount` double NOT NULL,
  `from_customer_id` int(11) NOT NULL,
  `to_customer_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`id`, `code`, `dates`, `note`, `amount`, `from_customer_id`, `to_customer_id`, `account_id`, `warehouse_id`, `user_id`) VALUES
(1, '46564', '2024-02-27', 'hrhn', 45000, 1, 2, 2, 1, 1),
(2, '4224', '2024-02-14', 'vdfs', 32000, 3, 1, 3, 1, 1),
(3, '343', '2024-02-17', 'rrr', 4500, 2, 3, 3, 1, 1),
(4, '8988888', '2024-02-22', 'ghg', 6500, 3, 1, 1, 1, 1),
(5, '22', '2024-02-29', 'fff', 4300, 2, 1, 3, 1, 1),
(6, '354', '2024-03-01', 'zawadi', 59000, 2, 1, 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `coupon_spend`
--

CREATE TABLE `coupon_spend` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `amount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `code`, `name`, `note`, `phone`, `email`, `address`) VALUES
(1, '590', 'Candy', 'No Note', '', '', 'Temeke'),
(2, '223', 'Landy', 'no note', '54545456', 'Tabata', 'land@email.com'),
(3, '432', 'Bugalio', 'pope 2', '09876554432', 'bugalio@email.com', 'Buenos Ares'),
(4, '323', 'Happiness', 'regular', '0712567238', 'euphoria@email.com', 'Kurasini');

-- --------------------------------------------------------

--
-- Table structure for table `drawings`
--

CREATE TABLE `drawings` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `note` text NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drawings`
--

INSERT INTO `drawings` (`id`, `code`, `dates`, `warehouse_id`, `account_id`, `amount`, `note`, `user_id`) VALUES
(3, '767', '2024-03-01', 3, 1, 30000, 'the start', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `amount` double NOT NULL,
  `type_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`id`, `code`, `dates`, `note`, `amount`, `type_id`, `account_id`, `warehouse_id`, `user_id`) VALUES
(4, '34124', '2024-03-03', 'siku moja', 230000, 3, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `on_sale`
--

CREATE TABLE `on_sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `original_price` double NOT NULL,
  `percent_discount` double NOT NULL,
  `new_price` double NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `trans_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `discount` double NOT NULL,
  `lpo_no` varchar(50) NOT NULL,
  `proforma_no` varchar(50) NOT NULL,
  `dn_no` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `code`, `amount`, `account_id`, `trans_id`, `warehouse_id`, `user_id`, `pay_code`, `dates`, `discount`, `lpo_no`, `proforma_no`, `dn_no`, `note`) VALUES
(19, 'pur--1709803743', 20000, 1, 2, 1, 1, 'pay--1709803743', '2024-03-07', 0, '0', '0', '0', 'vfgsf'),
(20, 'pur--1709803743', 40000, 2, 2, 1, 1, 'pay--1709803743', '2024-03-07', 0, '0', '0', '0', 'vfgsf'),
(21, 'pur--1709804781', 40000, 1, 2, 2, 1, 'pay--1709804781', '2024-03-07', 0, '0', '0', '0', 'dfg'),
(22, 'pur--1709804781', 2000, 3, 2, 2, 1, 'pay--1709804781', '2024-03-07', 0, '0', '0', '0', 'dfg'),
(23, 'pur--1709804822', 42000, 2, 2, 1, 1, 'pay--1709804822', '2024-03-07', 0, '0', '0', '0', 'fgfg'),
(25, 'pur--1709805155', 20000, 2, 2, 2, 1, 'pay--1709805155', '2024-03-07', 0, '0', '0', '0', 'dfd'),
(26, 'pur--1709811105', 24000, 2, 2, 2, 1, 'pay--1709811105', '2024-03-07', 0, '0', '0', '0', 'dfg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `buying_price` double NOT NULL,
  `selling_price` double NOT NULL,
  `unit_id` int(11) NOT NULL,
  `min_q` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `code`, `name`, `note`, `brand_id`, `category_id`, `buying_price`, `selling_price`, `unit_id`, `min_q`) VALUES
(6, '313', 'violin', 'hbkadhj', 8, 3, 24000, 75000, 1, 10),
(7, '1121', 'kater', 'bfjf', 6, 6, 13000, 30000, 3, 8),
(8, '2443', 'revolver-gun', 'fgdgf', 5, 6, 14000, 55000, 1, 5),
(9, 'q3431', 'lg-tv-inch-30', 'black', 10, 7, 120000, 450000, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `pr_pay`
--

CREATE TABLE `pr_pay` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `discount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `code`, `dates`, `supplier_id`, `product_id`, `warehouse_id`, `quantity`, `price`, `user_id`) VALUES
(34, 'pur--1709803743', '2024-03-07', 1, 8, 1, 2, 14000, 1),
(35, 'pur--1709803743', '2024-03-07', 1, 7, 1, 3, 13000, 1),
(36, 'pur--1709804781', '2024-03-07', 2, 8, 2, 3, 14000, 1),
(37, 'pur--1709804822', '2024-03-07', 2, 8, 1, 3, 14000, 1),
(39, 'pur--1709805155', '2024-03-07', 2, 8, 2, 2, 14000, 1),
(40, 'pur--1709811105', '2024-03-07', 1, 6, 2, 1, 24000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_pay`
--

CREATE TABLE `purchase_pay` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `discount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `lpo_no` varchar(50) NOT NULL,
  `proforma_no` varchar(50) NOT NULL,
  `dn_no` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_return`
--

CREATE TABLE `purchase_return` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Manager'),
(3, 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sale_pay`
--

CREATE TABLE `sale_pay` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `discount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `lpo_no` varchar(50) NOT NULL,
  `proforma_no` varchar(50) NOT NULL,
  `dn_no` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sale_return`
--

CREATE TABLE `sale_return` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `code`, `name`, `note`) VALUES
(1, '7587', 'Grocery Loading', 'not less than 2000');

-- --------------------------------------------------------

--
-- Table structure for table `service_sale`
--

CREATE TABLE `service_sale` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL,
  `price` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_sale_pay`
--

CREATE TABLE `service_sale_pay` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `discount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `lpo_no` varchar(50) NOT NULL,
  `proforma_no` varchar(50) NOT NULL,
  `dn_no` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sr_pay`
--

CREATE TABLE `sr_pay` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `pay_code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `discount` double NOT NULL,
  `account_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES
(29, 8, 1, 5),
(30, 7, 1, 3),
(31, 8, 2, 5),
(33, 6, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `code`, `name`, `note`, `phone`, `email`, `address`) VALUES
(1, '198', 'Bituso General', 'no note', '0765098765', 'bituso@email.com', 'Posta'),
(2, '77u', 'General-Electronics', 'original', '0765986532', 'g.e.tz@email.com', 'Posta Mpya');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `trans_type_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `name`, `trans_type_id`) VALUES
(1, 'Sale', 1),
(2, 'Purchase', 2),
(3, 'Service_sale', 1),
(4, 'Purchase_return', 1),
(5, 'Sale_return', 2),
(6, 'Expenses', 2),
(7, 'Drawings', 2),
(8, 'Coupon', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `dates` date NOT NULL,
  `note` text NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trans_type`
--

CREATE TABLE `trans_type` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trans_type`
--

INSERT INTO `trans_type` (`id`, `name`) VALUES
(1, 'Pay-In'),
(2, 'Pay-Out');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `code`, `name`, `note`) VALUES
(1, '5345', 'Transport', 'including in-house shipping'),
(2, '5345', 'Umeme', 'electric bill'),
(3, '2323', 'Usafi', 'toilet and warehouse cleanliness '),
(4, '4532', 'Food', 'food for staff');

-- --------------------------------------------------------

--
-- Table structure for table `unique_activity`
--

CREATE TABLE `unique_activity` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount` double NOT NULL,
  `actual_amount` double NOT NULL,
  `trans_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unique_activity`
--

INSERT INTO `unique_activity` (`id`, `code`, `discount`, `actual_amount`, `trans_id`) VALUES
(1, 'pur--1709803743', 7000, 60000, 2),
(2, 'pur--1709804781', 0, 42000, 2),
(3, 'pur--1709804822', 0, 42000, 2),
(5, 'pur--1709805155', 0, 28000, 2),
(6, 'pur--1709811105', 0, 24000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`) VALUES
(1, 'Piece'),
(2, 'Kg'),
(3, 'Litre'),
(4, 'Boxes');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `passcode` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `code`, `passcode`, `role_id`, `phone`, `email`, `warehouse_id`, `note`) VALUES
(1, 'Aladin', '222', '123', 1, '0789234519', 'emarich@gmail.com', 1, 'no note'),
(2, 'Beliza', 'b45', '56Beliza2000', 2, '0789231465', 'belz@email.com', 1, 'from Lazio'),
(3, 'Luka ', 'luk234', 'lukadoncic2024', 3, '18004587610', 'doncic@email.com', 1, 'Indiana Pacers');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `code`, `name`, `address`, `note`) VALUES
(1, '222', 'Warehouse-Kkoo', 'Kariakoo', 'No Note'),
(2, '890', 'WH-Sinza', 'Sinza', 'mori'),
(3, 'wh-bs5', 'Baraza-WH', 'SalaSala', 'main');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon`
--
ALTER TABLE `coupon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon_spend`
--
ALTER TABLE `coupon_spend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drawings`
--
ALTER TABLE `drawings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `on_sale`
--
ALTER TABLE `on_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pr_pay`
--
ALTER TABLE `pr_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_pay`
--
ALTER TABLE `purchase_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_return`
--
ALTER TABLE `purchase_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_pay`
--
ALTER TABLE `sale_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_return`
--
ALTER TABLE `sale_return`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_sale`
--
ALTER TABLE `service_sale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_sale_pay`
--
ALTER TABLE `service_sale_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sr_pay`
--
ALTER TABLE `sr_pay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trans_type`
--
ALTER TABLE `trans_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unique_activity`
--
ALTER TABLE `unique_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `coupon`
--
ALTER TABLE `coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `coupon_spend`
--
ALTER TABLE `coupon_spend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `drawings`
--
ALTER TABLE `drawings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `on_sale`
--
ALTER TABLE `on_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pr_pay`
--
ALTER TABLE `pr_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `purchase_pay`
--
ALTER TABLE `purchase_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `purchase_return`
--
ALTER TABLE `purchase_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sale_pay`
--
ALTER TABLE `sale_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sale_return`
--
ALTER TABLE `sale_return`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `service_sale`
--
ALTER TABLE `service_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_sale_pay`
--
ALTER TABLE `service_sale_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sr_pay`
--
ALTER TABLE `sr_pay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `transfer`
--
ALTER TABLE `transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trans_type`
--
ALTER TABLE `trans_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `unique_activity`
--
ALTER TABLE `unique_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
