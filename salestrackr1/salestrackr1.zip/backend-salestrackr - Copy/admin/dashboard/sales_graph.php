<?php
// sales_graph.php ***
include('../../config.php'); // Include your database connection file

$defaultStartDate = date('Y-m-d', strtotime('-1 week'));
$defaultEndDate = date('Y-m-d');

$querySales = "SELECT DATE(payments.dates) AS sale_date, SUM(payments.amount) AS total_sale
    FROM payments
    JOIN transactions ON payments.trans_id = transactions.id
    WHERE transactions.name IN ('Sale')
    AND payments.dates BETWEEN '$defaultStartDate' AND '$defaultEndDate'
    GROUP BY sale_date
    ORDER BY sale_date";

$result = $conn->query($querySales);

$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = array(
        'date' => $row['sale_date'],
        'total_sale' => $row['total_sale']
    );
}

header('Content-Type: application/json');
echo json_encode($data);
$conn->close();
?>
