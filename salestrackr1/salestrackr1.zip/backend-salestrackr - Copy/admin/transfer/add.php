<?php
// admin/transfer/add.php

include('../../config.php');

// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session


function generateTransCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();

    // Generate random three-digit number
    $randomNumber = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
    
    // Concatenate the components to form the receipt code
    $code = 'tr-' . '-' . $timestamp . '-' . $randomNumber;

    return $code;
}



// Check if the form is submitted for adding sale
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add']) && isset($_POST['productid']) && isset($_POST['quantity'])) {
    $code = isset($_POST['code']) ? $_POST['code'] : null;

    $date = isset($_POST['date']) ? $_POST['date'] : null;

    $fromWarehouseId = isset($_POST['from_warehouse_id']) ? $_POST['from_warehouse_id'] : null;
    $toWarehouseId = isset($_POST['to_warehouse_id']) ? $_POST['to_warehouse_id'] : null;

    $note = isset($_POST['note']) ? $_POST['note'] : null;


    $user_id = $_SESSION['user_id'];

    if ($code == null || $date == null || $note == null) {
        $code = generateTransCode();
        $date = date('Y-m-d');
        $note = 'No Note';
    }
    

    if ($code !== null && $date !== null && $toWarehouseId!== null && $fromWarehouseId !== null
        && $note !== null) {

        // Iterate over the rows in the table
        for ($i = 0; $i < count($_POST['productid']); $i++) {
            $productId = $_POST['productid'][$i];
            $quantity = $_POST['quantity'][$i];

            
            $fromStockSql = "SELECT quantity FROM stock WHERE product_id = '$productId' AND warehouse_id = '$fromWarehouseId'";
            $fromStockResult = $conn->query($fromStockSql);

            if ($fromStockResult->num_rows > 0) {

                $fromStockRow = $fromStockResult->fetch_assoc();
                $fromStockQuantity = $fromStockRow['quantity'];

                if ($fromStockQuantity >= $quantity) {
                    // subtract from one warehouse
                    $subtractSql = "UPDATE stock SET quantity = quantity - $quantity WHERE product_id = $productId AND warehouse_id = $fromWarehouseId";
                    $conn->query($subtractSql);

                    // add to another warehouse
                    $addSql = "INSERT INTO stock (warehouse_id, product_id, quantity) VALUES ($toWarehouse, $productId, $quantity)
                                ON DUPLICATE KEY UPDATE quantity = quantity + $quantity";
                    $conn->query($addSql);

                    // insert record into transfer table
                    $transferSql = "INSERT INTO transfer(code, dates, note, from_warehouse_id, to_warehouse_id, quantity, user_id, product_id)
                                    VALUES ('$code', '$date', '$note', '$fromWarehouseId', '$toWarehouseId', '$quantity', '$user_id', '$productId')";
                    $conn->query($transferSql);
                } else {
                    echo "Error: Insufficient stock for product ID $productId in warehouse $fromWarehouseId";
                }

            } else {
                // Handle the case where the combination doesn't exist (ideally, this should not happen in a well-maintained system)
                echo "Error: Stock not found for product $productId in warehouse $fromWarehouseId";
            }

        }
    }
}


// Retrieve unit data for dropdown
$unit_query = "SELECT id, name FROM unit";
$unit_result = $conn->query($unit_query);
$units = $unit_result->fetch_all(MYSQLI_ASSOC);

// Retrieve product data for dropdown
$product_query = "SELECT id, name FROM product";
$product_result = $conn->query($product_query);
$products = $product_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);



// Close the database connection
$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Add Transfer';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="add--section">

            <form class="add-details" action="" method="post">
                <div class="add-option">
                    <div class="options">
                        <div class="code">
                            <label for="">Code:</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="date">
                            <label for="">Date:</label><br>
                            <input type="date" name="date">
                        </div>
                        <div class="from-warehouse">
                            <label for="">FROM:</label><br>
                            <select class="datalist-people" onchange="handleWarehouseSelection()" name="from_warehouse_id" id="fromWarehouseId">
                                <option value="" selected disabled>Select a warehouse</option>
                                <?php
                                    foreach ($warehouses as $warehouse) {
                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="to-warehouse">
                            <label for="toWarehouseId">TO:</label><br>
                            <select class="datalist-people" name="to_warehouse_id" id="toWarehouseId">
                                <option value="" selected disabled>Select a warehouse</option>
                                <?php
                                    foreach ($warehouses as $warehouse) {
                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="choose-product">
                            <label for="search">Choose Product:</label><br>
                            <input list="products" id="search" name="search" class="datalist-product">
                            <datalist id="products"></datalist>
                        </div>
                    </div>
                </div>

                <div class="add-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Product Name</th>
                                <th>Unit</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody id="productTableBody"></tbody>
                    </table>
                </div>
                <div class="add-footer">
                    <div class="footer-amounts" style="display: none;">
                        <div class="discount">
                            <label for="discount">Discount:</label>
                            <input id="discount" oninput="updateTotal()" name="discount" type="number" value="0.00">
                        </div>
                        <div class="sub-total">
                            <span>Sub-total:</span>
                            <figure id="subtotal">0.00</figure>
                        </div>
                    </div>
                    <div class="footer-btn">
                        <button id="sellBtn">
                            <span class="sell">Transfer</span>
                            <div class="total">
                                <figure id="total">0.00</figure>
                                <input type="hidden" name="actual_amount" id="totalInput">
                            </div>
                        </button>
                    </div>
                </div>


            </form>
        </div>
    </section>




    <?php
    include('../../assets/components/scripts-1.php');
    ?> 
    
    <script>
        // Function to handle warehouse selection
        function handleWarehouseSelection() {
            var selectedWarehouse = document.getElementById('fromWarehouseId').value;

            // AJAX request to fetch product details based on the selected warehouse
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        var productList = JSON.parse(xhr.responseText);

                        // Update the datalist options with the new product list
                        var datalist = document.getElementById('products');
                        datalist.innerHTML = ''; // Clear previous options
                        productList.forEach(function (product) {
                            datalist.innerHTML += `<option value="${product.name}">`;
                            datalist.innerHTML += `<option value="${product.code}">`;
                        });
                    } else {
                        console.error('Error fetching products:', xhr.statusText);
                        // Handle the error here, e.g., display an alert to the user
                    }
                }
            };

            // Replace 'get_products_by_warehouse.php' with your actual endpoint
            xhr.open("GET", "get_products_by_warehouse.php?warehouse=" + selectedWarehouse, true);
            xhr.send();
        }

        // Update your existing AJAX request in the main file
        function handleProductSelection() {
            var selectedProduct = document.getElementById('search').value;
            var selectedWarehouse = document.getElementById('fromWarehouseId').value;  // Add this line

            // AJAX request to fetch product details
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        var productDetails = JSON.parse(xhr.responseText);

                        displayProductDetails(productDetails);

                    } else {
                        console.error('Error fetching product details:', xhr.statusText);
                        // Handle the error here, e.g., display an alert to the user
                    }
                }
            };

            // Include both product and warehouse parameters in the URL
            xhr.open("GET", "get_product_details.php?product=" + selectedProduct + "&warehouse=" + selectedWarehouse, true);
            xhr.send();
        }

        // Function to display product details
        function displayProductDetails(productDetails) {
            if (productDetails.error) {
                console.error('Error:', productDetails.error);
            } else {
                var table = document.getElementById('productTableBody');
                var newRow = table.insertRow();
                newRow.innerHTML = `<td>${productDetails.code}</td>
                                <td class="td-product">${productDetails.name}</td>
                                <td>${productDetails.unit_name}</td>
                                <td class="td-amount">${productDetails.selling_price}</td>
                                <td><input type="number" name="quantity[]" value="1" min="1" oninput="updateAmount(this)" class="quantity-input"></td>
                                <td class="td-amount">${productDetails.selling_price}</td>
                                <td><i class="fa fa-times remove-icon" onclick="removeRow(this)"></i></td>
                                <input type="hidden" name="productid[]" value="${productDetails.id}">
                                <input type="hidden" name="price[]" value="${productDetails.selling_price}">`;

                // Update subtotal and total values
                updateTotal();
            }
        }

        // Function to remove the row when the "fa-times" icon is clicked
        function removeRow(icon) {
            var row = icon.closest('tr');
            row.remove();

            // Update subtotal and total values after removing the row
            updateTotal();
        }

        // Function to update amount based on quantity
        function updateAmount(input) {
            var row = input.parentNode.parentNode;
            var price = parseFloat(row.cells[3].textContent);
            var quantity = parseInt(input.value);
            var amount = price * quantity || 0;
            row.cells[5].textContent = amount.toFixed(2);
            // Update subtotal and total values
            updateTotal();
        }

        // Function to update total values
        function updateTotal() {
            var table = document.getElementById('productTableBody');
            var rows = table.querySelectorAll('tr');
            var subtotal = 0;

            rows.forEach(function (row) {
                var amount = parseFloat(row.cells[5].textContent);
                subtotal += amount;
            });

            var discount = parseFloat(document.getElementById('discount').value) || 0;
            var total = subtotal - discount;

            document.getElementById('subtotal').textContent = subtotal.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            document.getElementById('total').textContent = total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
            // Update the value of the hidden input field
            document.getElementById('totalInput').value = total.toFixed(2);
        }


        $(document).ready(function () {
            // Event listener for the Sell button
            $('#sellBtn').on('click', function () {
                $('#salePaymentContainer').fadeIn();
                $('.popup').addClass('active');
            });

            // Event listener to close the payment popup
            $('#closePay').on('click', function () {
                $('#salePaymentContainer').fadeOut();
            });
    
            // Event listener for warehouse selection
            $('#warehouseId').on('change', function () {
                handleWarehouseSelection();
            });

            // Event listener for product selection
            $('#search').on('input', function () {
                handleProductSelection();
            });

        });
    </script>



</body>
</html>