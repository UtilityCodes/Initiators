<?php
// Retrieve user_id and warehouse_id from session
session_start(); // Make sure to start the session
?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Transfer List';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <a href="add.php">
                        <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    </a>

                </div>
                <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Date</th>
                        <th>Product Name</th>
                        <th>FROM</th>
                        <th>TO</th>
                        <th>Quantity</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql =  "SELECT 
                                transfer.id as id,
                                transfer.code as code, 
                                transfer.dates as dates,
                                transfer.quantity as quantity,
                                product.name as product_name,
                                from_warehouse.name as from_warehouse_name,
                                to_warehouse.name as to_warehouse_name
                            FROM transfer
                            INNER JOIN warehouse as from_warehouse ON transfer.from_warehouse_id = from_warehouse.id
                            INNER JOIN warehouse as to_warehouse ON transfer.to_warehouse_id = to_warehouse.id
                            INNER JOIN product ON transfer.product_id = product.id
                            GROUP BY transfer.id
                            ORDER BY transfer.dates ASC ";

                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-action"><?php echo $row['code'];?></td>
                                <td class="td-action"><?php echo $row['dates'];?></td>
                                <td class="td-action"><?php echo $row['product_name'];?></td>
                                <td class="td-action"><?php echo $row['from_warehouse_name'];?></td>
                                <td class="td-action"><?php echo $row['to_warehouse_name'];?></td>
                                <td class="td-action"><?php echo $row['quantity'];?></td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>


    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">FROM:</label><br>
                            <input list="fromWh" class="datalist-input" id="fromWhId" name="fromWh_id" autocomplete="off" required>

                            <datalist id="fromWh">
                                <option value="WH-1"></option>
                                <option value="WH-4"></option>
                                <option value="WH-8"></option>
                            </datalist>
                        </div>
                        <div class="filter-datalist">
                            <label for="">TO:</label><br>
                            <input list="toWh" class="datalist-input" id="toWhId" name="toWh_id" autocomplete="off" required>

                            <datalist id="toWh">
                                <option value="WH-3"></option>
                                <option value="WH-4"></option>
                                <option value="WH-1"></option>
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



    


    <script src="../../assets/js/skeleton.js"></script>
    
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../../assets/js/action-dropdown.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>
    <script src="../../assets/js/datatables.js"></script>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>