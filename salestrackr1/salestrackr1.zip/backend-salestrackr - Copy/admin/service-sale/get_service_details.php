<?php
include '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['service'])) {
    $serviceName = $_GET['service'];

    // Fetch service details based on the provided name or barcode
        $serviceDetailsQuery = "SELECT 
                                services.id as id,
                                services.name as name,
                                services.code as code
                            FROM services

                            WHERE services.name = '$serviceName' OR services.code = '$serviceName'";
    $result = $conn->query($serviceDetailsQuery);

    if ($result && $result->num_rows > 0) {
        $serviceDetails = $result->fetch_assoc();

        // Return service details as JSON
        header('Content-Type: application/json');
        echo json_encode($serviceDetails);
    } else {
        // service not found
        header("HTTP/1.1 404 Not Found");
        echo json_encode(['error' => 'service not found']);
    }
} else {
    // Invalid request
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();





